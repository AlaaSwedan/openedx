<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdvertisementsdataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('advertisementsdata', function (Blueprint $table) {
            $table->increments('id');
            $table->string('advertiseName');
            $table->string('type');
            $table->string('category');
            $table->string('amount');
            $table->string('status');
            $table->string('segment');
            $table->string('place');
            $table->string('owner');
            $table->string('periority');
            $table->string('start');
            $table->string('end');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('advertisementsdata');
    }
}
