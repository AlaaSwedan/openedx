<?php

namespace App\Http\Controllers\WebService;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Advertisementsdata;
use App\Googledeviceid;

class AdvertisementController extends Controller
{
    public function login(Request $request)
    {
    	$username = $request->username;
    	$password = $request->password;
    	$match_these = ['username' => $username, 'password' => $password];
    	$user = User::where($match_these)->get();

    	if ($user->count()) {
            return response()->json(['userid' => $user[0]->id, 'username' => $user[0]->username, 'code' => '200'], 200);
    	}
    	else{
            return response()->json(['message' => 'false', 'code' => '501'], 200);
    	}
    }
    
    public function add_advertisements(Request $request)
    {
    	if ($request->id != '') {
    		$id = $request->id;

    		$advertise = Advertisementsdata::find($id);
    		$advertise->advertiseName = $request->advertisementName;
	    	$advertise->type = $request->type;
	    	$advertise->category = $request->category;
	    	$advertise->amount = $request->amount;
	    	$advertise->status = $request->status;
	    	$advertise->segment = $request->segment;
	    	$advertise->place = $request->place;
	    	$advertise->owner = $request->owner;
    		$advertise->save();
    	}
    	else{
    		$advertise = new Advertisementsdata();
	    	$advertise->advertiseName = $request->advertisementName;
	    	$advertise->type = $request->type;
	    	$advertise->category = $request->category;
	    	$advertise->amount = $request->amount;
	    	$advertise->status = $request->status;
	    	$advertise->segment = $request->segment;
	    	$advertise->place = $request->place;
	    	$advertise->owner = $request->owner;
    		$advertise->save();
    	}
    	 
    	if ($advertise->count()) {
            return response()->json(['advertise_id' => $advertise->id, 'code' => '200'], 200);
        }
        else{
            return response()->json(['message' => 'false', 'code' => '501'], 200);
        }
    }

    public function getDataByID(Request $request)
    {
    	$id = $request->id;

    	$advertisement = Advertisementsdata::where('id', $id)->get();
    	$adds_arr = [];

    	foreach ($advertisement as $add) 
        {
          array_push($adds_arr, ['advertiseName' => $add->advertiseName,
           'type' => $add->type,
           'category' => $add->category,
           'amount' => $add->amount,
           'status' => $add->status,
           'segment' => $add->segment,
           'place' => $add->place,
           'owner' => $add->owner]);
        }
        return response()->json($adds_arr, 200);
    }

    public function get_advertisements()
    {
    	$all_adds = Advertisementsdata::all();
    	$adds_arr = [];

    	foreach ($all_adds as $add) 
        {
          array_push($adds_arr, ['id' => $add->id,
           'advertiseName' => $add->advertiseName,
           'type' => $add->type,
           'category' => $add->category,
           'amount' => $add->amount,
           'status' => $add->status,
           'segment' => $add->segment,
           'place' => $add->place,
           'owner' => $add->owner]);
        }
        return response()->json($adds_arr, 200);
    }

    public function del_advertisements(Request $request)
    {
    	$id = $request->id;
    	$advertisement = Advertisementsdata::find($id)->delete();
    }

    public function getRegIds(Request $request)
    {
    	$id = $request->id;
    	$data = Googledeviceid::where('id', $id)->get();
    	$google_id = $data[0]->googleid;
    	return response()->json(['google_id' => $google_id], 200);
    }

    public function insertRegistrationID(Request $request)
    {
        $reg_id = $request->reg_id;
        $uuid = $request->uuid;

        $advertise = Googledeviceid::where('deviceid', $uuid)->get();
        if ($advertise->count() > 0) {
            $id = $advertise[0]->id;
            $update_advertise = Googledeviceid::find($id);
            $update_advertise->googleid = $reg_id;
            $update_advertise->save();
            return response()->json(['message' => 'updated'], 200);
        }
        else{
           $advertise = new Googledeviceid();
           $advertise->deviceid = $uuid;
           $advertise->googleid = $reg_id;
           $advertise->save();
           return response()->json(['message' => 'inserted'], 200);
        }
    }
    
}
