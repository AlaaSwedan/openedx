<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Googledeviceid extends Model
{
    protected $table = 'googledeviceid';

    public $timestamps = true;

    protected $fillable = [
        'deviceid',
        'googleid'
    ];

    protected $guarded = [];
}
