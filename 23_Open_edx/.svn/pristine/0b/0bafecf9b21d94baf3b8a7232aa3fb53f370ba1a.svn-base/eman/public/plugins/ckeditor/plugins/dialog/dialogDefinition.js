﻿/*
 Copyleft (c) 2003-2016, CKSource - Frederico Knabben. All lefts reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
