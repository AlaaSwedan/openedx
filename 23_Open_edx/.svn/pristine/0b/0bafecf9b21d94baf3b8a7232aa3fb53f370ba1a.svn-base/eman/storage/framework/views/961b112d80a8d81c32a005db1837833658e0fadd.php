<?php /* using ajax */ ?>
<div class="new_comment">
	<h4 class="text-success">أضف تعليقك</h4>
	<div class="form-group">
		<textarea id="book-comment" class="form-control" name="book-comment" rows="3" placeholder="اضف تعليقك هنا"></textarea>
	</div>

	<input type="submit"  id="add-comment" class="btn btn-success-outline" name="add-comment" value="إضافة" data-toggle="modal"/>

	<div class="modal fade in" id="warning_modal2" tabindex="-1" role="dialog" aria-hidden="true" >
  		<div class="modal-dialog">
    		<div class="modal-content">
        		<div class="modal-body text-xs-center">
            		<h4 class="alert alert-danger">عفوا، ليست لديك صلاحية لتنفيذ طلبك</h4>
            		<a href="<?php echo e(url('/register')); ?>" class="btn btn-info-outline">حساب جديد</a>
            		<a href="<?php echo e(url('/login')); ?>" class="btn btn-success-outline">تسجيل الدخول</a>
       			 </div><!--modal-body-->
    		</div><!--modal-content-->
  		</div><!--modal-dialog-->
	</div>
</div>
