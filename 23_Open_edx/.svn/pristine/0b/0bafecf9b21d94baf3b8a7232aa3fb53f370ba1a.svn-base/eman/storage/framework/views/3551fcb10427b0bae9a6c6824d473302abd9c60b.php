<footer>
    <div class="container">
        <div class="row">
            <aside class="col-lg-6 col-md-8 col-xs-12">
                <nav class="footer_menu">
                    <ul class="ul_clear">
                        <li><a class="text-muted" href="">دليل المستخدم</a></li>
                        <li><a class="text-muted" href="">مساعدة</a></li>
                        <li><a class="text-muted" href="">دعم</a></li>
                        <li><a class="text-muted" href="">اتصل بنا</a></li>
                        <li><a class="text-muted" href="">سياسة الخصوصية</a></li>
                    </ul>
                </nav>
                <address class="text-muted">المملكة العربية السعودية - الرياض - حي الغدير مخرج (5) طريق الملك عبد العزيز - خلف بنك ساب</address>
            </aside><!--end col-xs-12-->
            <aside class="col-lg-6 col-md-4 col-xs-12">
                <ul class="ul_clear footer_social">
                    <li><a href="#" class="facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" class="twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" class="mail" target="_blank"><i class="fa fa-paper-plane-o"></i></a></li>
                    <li><a href="#" class="instagram" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#" class="youtube" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
            </aside><!--end col-xs-12-->
        </div><!--end row-->
    </div><!--end container-->
</footer>
<!--js files-->
<script type="text/javascript" src="<?php echo e(url('js/tether.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/modernizr.custom.js')); ?>"></script>   
<script type="text/javascript" src="<?php echo e(url('js/jquery.bookblock.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/jquery.localScroll.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/jquery.scrollTo.min.js')); ?>"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

<script type="text/javascript">
$(document).ready(function(e) {
$("#bookText").bind('copy', function(){
    alert(e.clipboardData.getData('text/plain')
)
})
    //ajax laravel
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

//page id default
window.pageId=1;

    $('[data-toggle="tooltip"]').tooltip()
    $('.page_menu_btn').click(function(){
       $('.page_top_nav').toggleClass('hidden-md-down') ;
   });
    //////////////////
    var res_header_height=$('body > header').height();  
    $(window).scroll(function(){
      var sticky = $('.menu_bar'),scroll = $(window).scrollTop();
      if (scroll >=res_header_height ) sticky.addClass('fixed_header');
      else sticky.removeClass('fixed_header');
  });
});
</script>
<?php /* single book 1 */ ?>
<script type="text/javascript">
$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
    $('.b_scroll').localScroll({
        target: '.book_article', // could be a selector or a jQuery object too.
        queue:true,
        duration:1000,
        hash:true,

    });
    $('.page_menu_btn').click(function(){
       $('.page_top_nav').toggleClass('hidden-md-down') ;
   });
    $( '#bb-bookblock' ).bookblock({
        nextEl:'#bb-nav-next',
        prevEl: '#bb-nav-prev',
        direction : 'rtl',
    });
    $( '#book_menu_btn' ).click(function(){
        $('.bb-custom-wrapper').toggleClass('b_menu_show') ;
        return false;
    });
    $('#notes_tab').on('click', '.nav-tabs a', function(){
        $(this).closest('.dropdown').addClass('dontClose');
    });

    $('#book_drop').on('hide.bs.dropdown', function(e) {
        if ( $(this).hasClass('dontClose') ){
            e.preventDefault();
        }
        $(this).removeClass('dontClose');
    });
    //////////////////
    var res_header_height=$('body > header').height();   
    $(window).scroll(function(){
      var sticky = $('.menu_bar'),scroll = $(window).scrollTop();
      if (scroll >=res_header_height ) sticky.addClass('fixed_header');
      else sticky.removeClass('fixed_header');
  });

    
});
</script>
<?php /* go to page using TOC Book1 page */ ?>
<script type="text/javascript" src="<?php echo e(url('js/TOC-book1-goToPage.js')); ?>"></script>
<?php /* add bookmark */ ?>
<script type="text/javascript" src="<?php echo e(url('js/add-bookmark.js')); ?>"></script>
<?php /* add Note */ ?>
<script type="text/javascript" src="<?php echo e(url('js/add-note.js')); ?>"></script>

<?php /* add comment */ ?>
<script type="text/javascript" src="<?php echo e(url('js/add-comment.js')); ?>"></script>

<?php /* delete note */ ?>
<script type="text/javascript" src="<?php echo e(url('js/delete-note.js')); ?>"></script>
<?php /* delete bookmark */ ?>
<script type="text/javascript" src="<?php echo e(url('js/delete-bookmark.js')); ?>"></script>

<?php /* edit note */ ?>
<script type="text/javascript" src="<?php echo e(url('js/edit-note.js')); ?>"></script>

<?php /* edit bookmark */ ?>
<script type="text/javascript" src="<?php echo e(url('js/edit-bookmark.js')); ?>"></script>
</body>
</html>
