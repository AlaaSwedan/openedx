<!-- sarah -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <?php /* ajax laravel */ ?>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>تفسير</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="<?php echo e(url('css/bootstrap-rtl.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(url('css/dsoft_admin.min.css')); ?>">
  <!-- Theme color -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/skin-blue.css')); ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(url('css/blue.css')); ?>">
  <!--general style-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/styleAdmin.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/style-responsive.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/drag-drop-plugin.css')); ?>">
  <script src="//cdn.ckeditor.com/4.5.10/standard/ckeditor.js"></script>

  <?php /* add toc disable pages selection */ ?>
  <style type="text/css">
    .noselect {
      -webkit-touch-callout: none; /* iOS Safari */
      -webkit-user-select: none;   /* Chrome/Safari/Opera */
      -khtml-user-select: none;    /* Konqueror */
      -moz-user-select: none;      /* Firefox */
      -ms-user-select: none;       /* Internet Explorer/Edge */
      user-select: none;           /* Non-prefixed version, currently
}
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini hold-transition login-page">
  <!-- Site wrapper -->
  <div class="wrapper">

    <header class="main-header">
      <!-- Logo -->
      <a href="/" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>تفسير</b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>تفسير</b></span>
      </a>
      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
              </a>
              <ul class="dropdown-menu">

                <!-- Menu Footer-->
                <li class="user-footer">
                  <div class="pull-left">
                    <a href="<?php echo e(url("/profile/".Auth::user()->id."")); ?>" class="btn btn-default btn-flat">الصفحة الشخصية</a>
                  </div>
                  <div class="pull-right">
                    <a href="<?php echo e(url('/logout')); ?>" class="btn btn-default btn-flat">خروج</a>
                  </div>
                </li>
              </ul>
            </li>
          </ul>
          
        </div>
      </nav>
    </header>

    <!-- =============================================== -->

    <!-- Left side column. contains the sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
        <!-- Sidebar user panel -->

        <!-- search form -->

        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
          <li class="header">القائمة الرئيسية</li>
          <li>
            <a href="/admin-panel/folders">
              <i class="fa fa-folder-open"></i> <span>المجلدات</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/main-topics">
              <i class="fa fa-archive"></i> <span>الموضوعات الرئيسية</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/letters">
              <i class="fa fa-quote-right"></i> <span>الأحرف</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/books">
              <i class="fa fa-book"></i> <span>الموضوعات</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/tocs">
              <i class="fa fa-align-right"></i> <span>الفهارس</span>
            </a>
          </li>
          
          
          
          <li>
            <a href="/admin-panel/resources">
              <i class="fa  fa-file-text"></i> <span> فهرس المصادر والمراجع</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/messages"><i class="fa fa-envelope-square"></i>
              <span>رسائل تواصل معنا</span>
              <span class="label label-primary pull-right">
                <?php 
                  use App\Http\Controllers\MessageController;
                  $msg = new MessageController;
                  $count_unread_msgs = $msg->count_unread();
                  echo $count_unread_msgs;
                ?>
              </span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/supports"><i class="  fa fa-envelope"></i> <span>رسائل الدعم الفني</span>
              <span class="label label-primary pull-right">
                <?php 
                  use App\Http\Controllers\SupportController;
                  $support_msg = new SupportController;
                  $count_unread_msgs = $support_msg->count_unread();
                  echo $count_unread_msgs;
                ?>
              </span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/users"><i class="fa fa-users"></i>
              <span> المستخدمين</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/departments">
              <i class="fa fa-cogs"></i> <span>الأقسام</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/managers">
              <i class="fa fa-wrench"></i> <span>المديرين</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/faq">
              <i class="fa fa-question"></i> <span>الأسئلة الشائعة</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/socials">
              <i class="fa  fa-globe"></i> <span>التواصل الإجتماعى</span>
            </a>
          </li>
          <li>
            <a href="/admin-panel/about-us">
              <i class="fa  fa-bookmark-o"></i> <span>عن الموسوعة</span>
            </a>
          </li>
        </ul>
      </section>
      <!-- /.sidebar -->
    </aside>

    <!-- =============================================== -->

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">

      </section>

      <!-- Main content -->
      <section class="content">

        <?php echo $__env->yieldContent('admin-content'); ?>


      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->

    <footer class="main-footer">Copyright &copy; 2014-2015 <a href="http://edeltasoft.com" target="_blank">Deltasoft</a> All rights reserved.</footer>

      <!-- Add the sidebar's background. This div must be placed
      immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->
    <!--===============js files================-->
    <!-- jQuery 2.1.4 -->
    <script src="<?php echo e(url('js/jquery-2.2.0.min.js')); ?>"></script>
    <script src="https://www.atlasestateagents.co.uk/javascript/tether.min.js"></script><!-- Tether for Bootstrap --> 

    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo e(url('js/icheck.min.js')); ?>"></script>
    <!-- app js -->
    <script src="<?php echo e(url('js/app.js')); ?>"></script>
    <!-- dsoft js -->
    <script src="<?php echo e(url('js/ds-script.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>

    <script>
      $(document).ready(function() {

  //ajax laravel
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });
});
</script>

<?php /* Sarah ElZeftawy scripts */ ?>
<script src="<?php echo e(url('js/drag-drop.js')); ?>"></script>
<script src="<?php echo e(url('js/check-all.js')); ?>"></script>
<script src="<?php echo e(url('js/refresh.js')); ?>"></script>
<script src="<?php echo e(url('js/add-folder.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-book.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-folder.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-maintopic.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-faq.js')); ?>"></script>
<script src="<?php echo e(url('js/publish.js')); ?>"></script>
<script src="<?php echo e(url('js/unpublish.js')); ?>"></script>
<script src="<?php echo e(url('js/go-to-book-pages.js')); ?>"></script>
<script src="<?php echo e(url('js/activate-delete.js')); ?>"></script>
<script src="<?php echo e(url('js/add-toc.js')); ?>"></script>
<script src="<?php echo e(url('js/publish-folder.js')); ?>"></script>
<script src="<?php echo e(url('js/publish-mainTopic.js')); ?>"></script>
<script src="<?php echo e(url('js/unpublish-folder.js')); ?>"></script>
<script src="<?php echo e(url('js/edit-folder.js')); ?>"></script>
<script src="<?php echo e(url('js/unpublish-mainTopic.js')); ?>"></script>
<script src="<?php echo e(url('js/add-main-topic.js')); ?>"></script>
<script src="<?php echo e(url('js/add-faq.js')); ?>"></script>
<script src="<?php echo e(url('js/publish-faq.js')); ?>"></script>
<script src="<?php echo e(url('js/unpublish-faq.js')); ?>"></script>
<script src="<?php echo e(url('js/search.js')); ?>"></script>
<?php /* <script src="<?php echo e(url('js/sort.js')); ?>"></script> */ ?>
<script src="<?php echo e(url('js/edit-about.js')); ?>"></script>
<script src="<?php echo e(url('js/edit-department.js')); ?>"></script>
<script src="<?php echo e(url('js/add-department.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-department.js')); ?>"></script>
<script src="<?php echo e(url('js/add-manager.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-manager.js')); ?>"></script>
<script src="<?php echo e(url('js/edit-manager.js')); ?>"></script>
<script src="<?php echo e(url('js/edit-maintopic.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-toc.js')); ?>"></script>
<script src="<?php echo e(url('js/delete-letter.js')); ?>"></script>
<script src="<?php echo e(url('js/filter.js')); ?>"></script>
<script src="<?php echo e(url('js/drag-drop-plugin-book.js')); ?>"></script>
<?php /* end sarah scripts */ ?>

<!-- Eman....... -->
<script src="<?php echo e(url('js/show_message.js')); ?>"></script>
<script src="<?php echo e(url('js/select_one.js')); ?>"></script>
<script src="<?php echo e(url('js/select_one_support_msg.js')); ?>"></script>
<script src="<?php echo e(url('js/select_one_user.js')); ?>"></script>
<script src="<?php echo e(url('js/select_all.js')); ?>"></script>
<script src="<?php echo e(url('js/select_all_supports.js')); ?>"></script>
<script src="<?php echo e(url('js/select_all_users.js')); ?>"></script>
<script src="<?php echo e(url('js/delete_msg.js')); ?>"></script>
<script src="<?php echo e(url('js/delete_support_msg.js')); ?>"></script>
<script src="<?php echo e(url('js/delete_users.js')); ?>"></script>
<script src="<?php echo e(url('js/exist_user.js')); ?>"></script>
<script src="<?php echo e(url('js/exist-toc.js')); ?>"></script>
<script src="<?php echo e(url('js/clickable_row.js')); ?>"></script>
<script src="<?php echo e(url('js/disable_search_btn.js')); ?>"></script>
<script src="<?php echo e(url('js/delete_msg_time.js')); ?>"></script>
<script src="<?php echo e(url('js/delete_support_time.js')); ?>"></script>
<script src="<?php echo e(url('js/filter_users.js')); ?>"></script>
<?php /* end Eman */ ?>

</body>
</html>
