<script>
	//var dataSet = [];
	$(document).ready(function() {
		getadvertisement();
	});
	function getadvertisement() {
		$.get("/ws/get_advertisements", function(data) {
			// console.log(data);
			var str = '';
			for (var i = 0; i < data.length; i++) {
				str += '<tr id="'+data[i]['id']+'">';
				str += '<td>' + data[i]['advertiseName'] + '</td>';
				str += '<td>' + data[i]['type'] + '</td>';
				str += '<td>' + data[i]['category'] + '</td>';
				str += '<td>' + data[i]['amount'] + '</td>';
				str += '<td>' + data[i]['status'] + '</td>';
				str += '<td>' + data[i]['segment'] + '</td>';
				str += '<td>' + data[i]['place'] + '</td>';
				str += '<td>' + data[i]['owner'] + '</td>';
				str += '<td>';
				str +='<button type="button" class="btn btn-warning btn-flat getUrl" onclick="goToURL(this);" url="/add" hiddenID="'+data[i]['id']+'"><i class="fa fa-pencil-square-o"></i></button>';
				str +='<button type="button" class="btn btn-warning btn-flat" onclick="del_advertisements(this.closest(\'tr\'));"><i class="fa fa-close"></i></button>';
				str+='</td>';
				str+='<td>';
				str +='<a onclick="sendNotification(this.closest(\'tr\'));" class="btn btn-block btn-social btn-success" style="text-align: center;">';
                str +='<i class="fa fa-twitter"></i>ارسل الإعلان';
              	str +='</a>';
				str+='</td>';
				str += '</tr>';
			}
			$("#example1 tbody").html(str);
			$('#example1').DataTable({
		      "paging": true,
		      "lengthChange": true,
		      "searching": true,
		      "ordering": true,
		      "info": true,
		      "autoWidth": false
		    });
		});
	}
	function del_advertisements($tr){
		$.get("/ws/del_advertisements?id="+$($tr).attr('id'), function(data) {
			alert("تم حذف الاعلان");
			$($tr).remove();
		});
	}
	function sendNotification($tr){
		$.get("/ws/notification?id="+$($tr).attr('id'), function(data) {
			alert("تم ارسال الاعلان");
		});
	}
</script>
<!-- Small boxes (Stat box) -->
<div class="row">
	<div class="col-md-12">
		<div class="col-xs-12" >
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">بيانات الإعلانات </h3>
					<h3 class="box-title"><!--<button type="button" url="add.html" title="إضافة اعلان" class="btn btn-block btn-primary btn-sm getUrl">إضافة اعلان</button>-->
						<a onclick="goToURL(this);" class="btn btn-block btn-social btn-dropbox getUrl" url="/add" title="إضافة اعلان" href="javascript:void(0);"><i class="fa fa-plus"></i> إضافة إعلان </a></h3>
				</div>
				<!-- /.box-header -->
				<div class="box-body">

					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>اسم الاعلان</th>
								<th>النوع</th>
								<th>التصنيف</th>
								<th>الرصيد</th>
								<th>الحالة</th>
								<th>الفئة المستهدفة</th>
								<th>المكان</th>
								<th>صاحب الاعلان</th>
								<td></td>
								<td></td>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
				<!-- /.box-body -->
			</div>
			<!-- /.box -->
		</div>
	</div>
	<!-- /.box -->
</div>
<!-- /.col -->

