<?php 
 use App\Http\Controllers\SocialController;
 $socials = new SocialController;

 ?>
<section class="home_content">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-xs-12">
                <h1 class="spon_title">الراعى الرسمي</h1>
                <div class="text-xs-center text-sm-left"><img src="<?php echo e(url('/')); ?>/images/sponser.png" alt=""/></div>
            </div><!--end col-xs-12-->
            <div class="col-lg-6 col-md-6 col-xs-12 ">
                <h1 class="spon_title"> إدارة التحرير</h1>
                <div class="text-xs-center text-sm-left">
                    <img src="<?php echo e(url('/')); ?>/images/rev1.png" alt=""/>
                    <img src="<?php echo e(url('/')); ?>/images/rev2.png" class="pull-lg-right"  alt=""/>
                </div>
            </div><!--end col-xs-12-->
        </div>
    </div><!--end container-->
</section>
<footer>
    <div class="container">
        <div class="row">
            <aside class="col-lg-6 col-md-8 col-xs-12">
                <nav class="footer_menu">
                    <ul class="ul_clear">
                        
                        <li><a class="text-muted" href="/faq">مساعدة</a></li>
                        <li><a class="text-muted" href="/support_us">دعم</a></li>
                        <li><a class="text-muted" href="/contact_us">اتصل بنا</a></li>
                        
                    </ul>
                </nav>
                <address class="text-muted">المملكة العربية السعودية - الرياض - حي الغدير مخرج (5) طريق الملك عبد العزيز - خلف بنك ساب</address>
            </aside><!--end col-xs-12-->
            <aside class="col-lg-6 col-md-4 col-xs-12">
                <ul class="ul_clear footer_social">
                    <li><a href="<?= $socials->pass()[0]; ?>" class="facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="<?= $socials->pass()[1]; ?>" class="twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="<?= $socials->pass()[2]; ?>" class="mail" target="_blank"><i class="fa fa-paper-plane-o"></i></a></li>
                    <li><a href="<?= $socials->pass()[3]; ?>" class="instagram" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="<?= $socials->pass()[4]; ?>" class="youtube" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
            </aside><!--end col-xs-12-->
        </div><!--end row-->
    </div><!--end container-->
</footer>
<!--js files-->
<script type="text/javascript" src="js/tether.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
    // sarah
    //ajax laravel
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
    
	$('.top_menu_btn').click(function(){
       $('.top_head_nav').toggleClass('hidden-sm-down') ;
    });
    //////////////////
   var res_header_height=$('.home_header').height();
    var window_height=$( window ).height() ;
	if(window_height>810){
        $('.home_header').css("height", window_height);
    }
    $(window).scroll(function(){
      var sticky = $('.menu_bar'),scroll = $(window).scrollTop();
        if(window_height<=650){
            var fixed=res_header_height;
        }else{
            var fixed=window_height;
        }
      if (scroll >= fixed) sticky.addClass('fixed_header');
      else sticky.removeClass('fixed_header');
    });

    ///////////////////
    if (window_height >= 810){
        $('.top_search_row,.main_head_cat,.top_logo,.top_head_nav,.site_desc').css({"padding-top":""+(window_height-810)/9+"px","padding-bottom":""+(window_height-810)/9+"px"});
    }
    ///////////

    //=======scroll========
	$(".scroll_to").click(function() {
        $('html,body').animate({
            scrollTop: $(".menu_bar").offset().top},
            'slow');
    });
	//=======
});
</script>

<?php /* sarah */ ?>
<?php /* search */ ?>
<script src="<?php echo e(url('js/front-search.js')); ?>"></script>
<?php /* most download */ ?>
<script src="<?php echo e(url('js/most-download.js')); ?>"></script>

<?php /* most share */ ?>
<script src="<?php echo e(url('js/most-share.js')); ?>"></script>

<?php /* most read */ ?>
<script src="<?php echo e(url('js/most-read.js')); ?>"></script>

</body>
</html>