<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"><i class="fa fa-share-alt"></i> الأكثر مشاركة</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>




            <?php foreach($shares as $item1): ?>
            <?php foreach($books as $item2): ?>

            <?php if($item2->id == $item1->book_id): ?>
            <div class="col-lg-6 col-md-6 col-xs-12 home_most_share">
                <div class="book_box">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="box_img"><img src="<?php echo e(url('/')); ?>/<?php echo e($item2->image); ?>" alt=""/></div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="box_content text-muted"> <?php echo e(str_limit($item2->description, $limit = 100, $end = '...')); ?> </div>
                            <div class="box_tools">
                                <a href="#"><i class="flaticon-paper fa-2x" title="طباعة" data-toggle="tooltip" data-placement="top"></i></a>
                                <a href="#"><i class="flaticon-connection fa-2x" title="نشر" data-toggle="tooltip" data-placement="top"></i></a>
                                <a href="#"><i class="flaticon-arrows fa-2x" title="تحميل" data-toggle="tooltip" data-placement="top"></i></a>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </div><!--end book_box-->
            </div><!--end col-lg-6 col-md-6 col-xs-12 home_most_share-->
            <?php endif; ?>
             <?php endforeach; ?>
            <?php endforeach; ?>

        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->