<?php $__env->startSection('admin-content'); ?>
<div class="row" >
	<div class="col-md-9" style="width: 100%;">
	  <div class="box box-primary">
	    <div class="box-header with-border">
	      <h3 class="box-title">نتائج البحث</h3>
	    </div>
	    <!-- /.box-header -->
	    <div class="box-body no-padding">
	      <div class="table-responsive mailbox-messages">
	       	<table class="table">
	        	<tbody>
	        	<tr>
              <th>اسم المستخدم</th>
              <th>البريد الإلكتروني</th>
              <th>تاريخ الالتحاق</th>
            </tr>
							<?php if($search_user_name->count()): ?>
								<?php foreach($search_user_name as $user_by_name): ?>
									<tr>
										<td><a href="<?php echo e(url('/admin-panel/users//'.$user_by_name->id.'/edit')); ?>"><?php echo e($user_by_name->name); ?></a></td>
										<td><?php echo e($user_by_name->email); ?></td>
										<td><?php echo e($user_by_name->created_at->format('Y-m-d')); ?></td>
									</tr>
								<?php endforeach; ?>
								
							<?php elseif($search_user_email->count()): ?>
								<?php foreach($search_user_email as $user_by_email): ?>
									<tr>
										<td><a href="<?php echo e(url('/admin-panel/users//'.$user_by_email->id.'/edit')); ?>"><?php echo e($user_by_email->name); ?></a></td>
										<td><?php echo e($user_by_email->email); ?></td>
										<td><?php echo e($user_by_email->created_at->format('Y-m-d')); ?></td>
									</tr>		
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
	        </table>
	      </div>
	    </div>
	    <!-- /.box-body -->
	    <div class="box-footer no-padding">
	    </div>
	  </div>
	  <!-- /. box -->
	</div>
	<!-- /.col -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>