<?php $__env->startSection('admin-content'); ?>
<div class="login-box">
	<div class="login-logo">
		<a href="http://edeltasoft.com"><img src="<?php echo e(url('images/adminLogo.png')); ?>" alt=""></a>
	</div><!-- /.login-logo -->
	<div class="login-box-body">
		<p class="login-box-msg">إدخل كمدير للموقع</p>
		<form role="form" action"<?php echo e(url('/admin-panel/login')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div class="form-group has-feedback">
				<input name="email" type="text" class="form-control" placeholder="البريد الإلكترونى">
				<span class="fa fa-envelope form-control-feedback"></span>
			</div>
			<div class="form-group has-feedback">
				<input name="password" type="password" class="form-control" placeholder="كلمة السر">
				<span class="fa fa-lock form-control-feedback"></span>
			</div>
			<div class="row">

				<div class="col-xs-4">
					<button type="submit" class="btn btn-primary btn-block btn-flat">إدخل</button>
				</div><!-- /.col -->
			</div>
		</form>

	</div><!-- /.login-box-body -->
</div><!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>