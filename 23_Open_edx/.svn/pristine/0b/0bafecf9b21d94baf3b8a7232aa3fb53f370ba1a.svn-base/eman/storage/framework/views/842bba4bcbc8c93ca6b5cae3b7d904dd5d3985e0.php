<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	
	<label>Page Content</label>
	<textarea name="page" rows="10" cols="30" class="form-control" id="page-edit-content-input"><?php echo e($page->content); ?></textarea><br/>
	<label>Page Order</label>
	<input type="text" name="order" id="page-edit-order-input" value="<?php echo e($page->page_order); ?>"/><br/>
	<label>Book ID</label>
	<select class="form-control" name="book" id="page-edit-book-input">
		<?php foreach($books as $book): ?>
		<option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>
		<?php endforeach; ?>
	</select><br/>
	<input page-id="<?php echo e($page->id); ?>" type="submit" id="page-edit-input" value="Edit Page" class="form-control"/>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>