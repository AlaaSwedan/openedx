<div class="tab-pane active" id="bookmark" role="tabpanel">
	<?php /* <?php foreach($bookmarks as $bookmark): ?> */ ?>
	<div class="notes_list">

		<a href="#"><i class="fa fa-trash-o"></i></a>
		<a href="#"><i class="fa fa-edit"></i></a>
		<?php /* <h4><?php echo e($bookmark->text); ?></h4> */ ?>
		<h4>hh</h4>
	</div><!--end notes_list-->
	<?php /* <?php endforeach; ?> */ ?>

	<!--end notes_list-->
</div><!--end tab-pane-->
