<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>

	<label>إسم المجلد</label>
	<input value="<?php echo e($folder->name); ?>" class="form-control" type="text" id='edit-folder-name-input' name="name"/><br/>
	<span id="edit-foldername-missing"></span>
	<label>الوصف</label><br/>
	<textarea name="edit_folder_description_input" id='edit_folder_description_input' rows="10" cols="30" class="form-control"><?php echo e($folder->description); ?></textarea><br/>
	<script>
            CKEDITOR.replace( 'edit_folder_description_input' );
    </script>
	<span id="edit-folderdesc-missing"></span>

	<input folder-id="<?php echo e($folder->id); ?>" type="submit" value="عدل المجلد" id='edit-folder-add-input' class="form-control"/>

</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>