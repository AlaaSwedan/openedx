<?php $__env->startSection('content'); ?>
<section class="pages_content">
    <div class="container">
       <div class="row">
          <div class="col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>   موضوعات تم مشاركتها   </h1>
            <?php foreach($books as $book): ?>
            <?php if($book->is_published): ?>
            <?php if(!$book->is_suspended): ?>

            <div class="book_block">
                <a href="/show-book/<?php echo e($book->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($book->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($book->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($book->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; ?>
        </div><!--end  col-xs-12-->
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>