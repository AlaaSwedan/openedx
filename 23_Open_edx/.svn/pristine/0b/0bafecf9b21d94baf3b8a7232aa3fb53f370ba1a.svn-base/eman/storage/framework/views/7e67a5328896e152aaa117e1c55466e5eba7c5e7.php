<?php $__env->startSection('admin-content'); ?>
	<div class="row" >
        <div class="col-md-9" style="width: 100%;">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">نتائج البحث</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="table-responsive mailbox-messages">
               	<table class="table">
                	<tbody>
										<?php if($message_subject->count()): ?>
											<?php foreach($message_subject as $message): ?>
												<?php if($message->is_read): ?>
													<tr>
														<td><a href="<?php echo e(url('/admin-panel/messages/'.$message->id.'/show')); ?>"><?php echo e($message->user_name); ?></a></td>
														<td><?php echo e($message->subject); ?></td>
														<td><?php echo e($message->created_at->format('Y-m-d')); ?></td>
													</tr>
												<?php else: ?>
													<tr bgcolor='#FFFAFA'>
														<td><b></b><a href="<?php echo e(url('/admin-panel/messages/'.$message->id.'/show')); ?>"><?php echo e($message->user_name); ?></a></b></td>
														<td><b></b><?php echo e($message->subject); ?></b></td>
														<td><b></b><?php echo e($message->created_at->format('Y-m-d')); ?></b></td>
													</tr>
												<?php endif; ?>
											<?php endforeach; ?>
											
										<?php elseif($user_name->count()): ?>
											<?php foreach($user_name as $msg): ?>
												<?php if($msg->is_read): ?>
													<tr>
														<td><a href="<?php echo e(url('/admin-panel/messages/'.$msg->id.'/show')); ?>"><?php echo e($msg->user_name); ?></a></td>
														<td><?php echo e($msg->subject); ?></td>
														<td><?php echo e($msg->created_at->format('Y-m-d')); ?></td>
													</tr>
												<?php else: ?>
													<tr bgcolor='#FFFAFA'>
														<td><b><a href="<?php echo e(url('/admin-panel/messages/'.$msg->id.'/show')); ?>"><?php echo e($msg->user_name); ?></a></b></td>
														<td><b><?php echo e($msg->subject); ?></b></td>
														<td><b><?php echo e($msg->created_at->format('Y-m-d')); ?></b></td>
													</tr>
												<?php endif; ?>
											<?php endforeach; ?>
											
										<?php endif; ?>
									</tbody>
                </table>
              </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer no-padding">
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>