<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>
	<form action='<?php echo e(url("/admin-panel/edit/resources")); ?>' role="form" method="post" class="from-group">
		<?php echo e(csrf_field()); ?>

		<label>أدخل المصادر و المراجع</label>
		<textarea required maxlength="255" class="form-control" type="text" name="resources" id="resources"><?php echo $resources->resource; ?></textarea>
		<script>
            CKEDITOR.replace( 'resources' );
        </script>
		<br/>


		<input type="submit" value="حفظ" class="form-control"/>
	</form>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>