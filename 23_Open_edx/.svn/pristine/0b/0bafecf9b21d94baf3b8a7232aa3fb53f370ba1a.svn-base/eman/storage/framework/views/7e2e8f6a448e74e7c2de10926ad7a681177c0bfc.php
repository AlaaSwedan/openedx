<?php $__env->startSection('content'); ?>
<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="fa fa-group"></i>  ادارة الموسوعة </h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>
            <?php foreach($deps as $dep): ?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <a href="/managers/<?php echo e($dep->id); ?>" class="mangement_block">
                    <h1><i class="fa fa-group fa-2x text-muted"></i></h1>
                   <?php echo e($dep->title); ?>

                </a>
            </div><!--end  col-md-4 col-sm-6 col-xs-12-->
            <?php endforeach; ?>
        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>