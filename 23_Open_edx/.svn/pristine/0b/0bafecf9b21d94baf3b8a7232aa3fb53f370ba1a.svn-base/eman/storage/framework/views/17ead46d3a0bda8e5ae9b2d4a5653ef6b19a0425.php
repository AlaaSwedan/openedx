<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	
	<label>Page Content</label>
	<textarea name="page" rows="10" cols="30" class="form-control" id="page-content-input"></textarea><br/>
	<label>Page Order</label>
	<input type="text" name="order" id="page-order-input"/><br/>
	<label>Book ID</label>
	<select class="form-control" name="book" id="page-book-input">
		<?php foreach($books as $book): ?>
		<option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>
		<?php endforeach; ?>
	</select><br/>
	<input type="submit" id="page-add-input" value="أضف صفحة" class="form-control"/>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>