<?php $__env->startSection('content'); ?>
<h1>أنت لست مدير الموقع</h1>
<a href="<?php echo e(URL::previous()); ?>">عودة إلى الصفحة السابقة</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>