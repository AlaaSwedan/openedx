<?php $__env->startSection('content'); ?>
<section class="pages_content">
    <div class="container">
        <div class="row">
            <?php if($error_msg == ''): ?>
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="fa fa-pencil"></i> تعديل البيانات الشخصية</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>
            <div class="col-xl-6 col-xl-offset-3 col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12">
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url("/profile/$user->id")); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group<?php echo e($errors->has('fullname') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <input  id="fullname" type="text" name="fullname" value="<?php echo e($user->fullname); ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="الاسم كاملاً" placeholder="الاسم كاملاً"/>
                            <?php if($errors->has('fullname')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('fullname')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div><!--end form-group-->
                    </div>


                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <input  id="name" type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="اسم المستخدم" placeholder="اسم المستخدم"/>
                            <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div><!--end form-group-->
                    </div>

                    <div class="form-group">
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" data-toggle="tooltip" data-placement="top" title="البريد الإلكتروني" placeholder="البريد الإلكتروني" readonly>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <div class="form-group">

                            <input id="password" type="password" class="form-control" name="password" data-toggle="tooltip" data-placement="top" title="كلمة السر" placeholder="كلمة السر">

                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" data-toggle="tooltip" data-placement="top" title="أعد إدخال كلمة السر" placeholder="أعد إدخال كلمة السر"/>

                            <?php if($errors->has('password_confirmation')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <input type="submit" class="btn btn-secondary" value="تعديل"/>
                </form>
                
          </div><!--end  col-xs-12-->
      </div><!--end row-->
      <hr>
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>   موضوعات تم مشاركتها   </h1>
            <?php if($books != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($books) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($books[$i]->is_published): ?>
            <div class="book_block">
                <a href="/show-book/<?php echo e($books[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($books[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($books[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($books[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($books) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/shared_books")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <div class="col-md-4 col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>  الموضوعات المقروءة    </h1>
            <?php if($books_reads != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($books_reads) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($books_reads[$i]->is_published): ?>
            <div class="book_block">
                <a href="/show-book/<?php echo e($books_reads[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($books_reads[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($books_reads[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($books_reads[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($books_reads) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/shared_books")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <div class="col-md-4 col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>  الموضوعات المطبوعة    </h1>
            <?php if($books_prints != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($books_prints) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($books_prints[$i]->is_published): ?>
            <div class="book_block">
                <a href="/show-book/<?php echo e($books_prints[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($books_prints[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($books_prints[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($books_prints[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($books_prints) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/printed_books")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <div class="clearfix"></div>
        <br>
        <br>
        <div class="col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>  المفضلة     </h1>
            <?php if($bookmarks != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($bookmarks) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($bookmarks[$i]->is_published): ?>

            <div class="book_block">
                <a href="/show-book/<?php echo e($bookmarks[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($bookmarks[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($bookmarks[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($bookmarks[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($bookmarks) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/bookmarks")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <div class="col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>  الملحوظات     </h1>
            <?php if($notes != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($notes) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($notes[$i]->is_published): ?>
            <div class="book_block">
                <a href="/show-book/<?php echo e($notes[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($notes[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($notes[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($notes[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($notes) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/notes")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <div class="col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>  موضوعات تم تحميلها     </h1>
            <?php if($books_downloads != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($books_downloads) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($books_downloads[$i]->is_published): ?>
            <div class="book_block">
                <a href="/show-book/<?php echo e($books_downloads[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($books_downloads[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($books_downloads[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($books_downloads[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($books_prints) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/downloaded_books")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <div class="col-sm-6 col-xs-12">
            <h1 class="page_title"> <i class="flaticon-book fa-lg"></i>  موضوعات بها تعليقات    </h1>
            <?php if($comments != ''): ?>
            <?php for($i = 0; $i < 3; $i++): ?>
            <?php if(count($comments) < $i+1): ?>
            <?php break;?>
            <?php endif; ?>
            <?php if($comments[$i]->is_published): ?>
            <div class="book_block">
                <a href="/show-book/<?php echo e($comments[$i]->id); ?>">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-xs-12">
                            <div class="block_img">
                                <img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($comments[$i]->image); ?>" alt=""/>
                            </div>
                        </div><!--end col-xs-12-->
                        <div class="col-lg-8 col-md-8 col-xs-12">
                            <div class="block_content text-muted">
                                <font color="#0EAE90"><?php echo str_limit($comments[$i]->title, $limit = 50, $end = ' ... '); ?></font>
                                <p><?php echo str_limit($comments[$i]->description, $limit = 50, $end = ' ... '); ?></p>
                            </div>
                        </div><!--end col-xs-12-->
                    </div><!--end row-->
                </a>
            </div><!--end book_box-->
            <?php endif; ?>
            <?php endfor; ?>
            <?php if(count($comments) > 3): ?>
            <a href="<?php echo e(url("/profile/$user->id/comments")); ?>" class="btn btn-link pull-xs-right">المزيد</a>
            <?php endif; ?>
            <?php else: ?>
            <p class="alert alert-danger">لا توجد نتائج</p>
            <?php endif; ?>
        </div><!--end  col-xs-12-->
        <?php else: ?>
        <div class="alert alert-danger" style="width:400px;margin-top:30px;margin-right:30px">
          <p style="margin-right:30px"><?php echo e($error_msg); ?></p>
        </div>
        <?php endif; ?>
    </div><!--end row-->
</div><!--end container-->
</section><!--end pages_content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>