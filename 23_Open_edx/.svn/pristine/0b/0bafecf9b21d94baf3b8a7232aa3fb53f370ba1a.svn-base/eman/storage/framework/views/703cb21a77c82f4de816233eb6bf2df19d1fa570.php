<?php $__env->startSection('content'); ?>

<div class="home_books_tab">
    <div class="row">

        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
            <h1 class="title"> الموضوعات </h1>
            <ul class="ul_clear" role="tablist">
                <?php foreach($topics as $key=>$item): ?>
                <li class="nav-item">
                    <a class="nav-link"  href="<?php echo e(url('/')); ?>/show-topics/<?php echo e($key +1); ?>" > <?php echo e($item->name); ?>


                        <i class="fa fa-angle-left"></i></a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>



            <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                <div class="tab-content">

                    <?php foreach($topics as $key=>$item): ?>
                    <?php foreach($books as $key=>$seconditem): ?>

                    <?php if(isset($id)): ?>
                    <?php if($item->id == $seconditem->main_topic_id && $seconditem->main_topic_id == $id ): ?>




                    <div class="tab-pane active" id="tab<?php echo e($key+1); ?>" role="tabpanel" aria-expanded="true">
                        <div class="h_tab_book">
                            <div class="row">
                                <div class="col-lg-3 col-md-4 col-xs-12">
                                    <div class="book_img"><img src="<?php echo e(url('/photo/books')); ?>/<?php echo e($seconditem->image); ?>" alt=""></div>
                                </div><!--end col-lg-3 col-xs-12-->
                                <div class="col-lg-9 col-md-8 col-xs-12">
                                    <div class="book_content text-muted line_text"><?php echo e(str_limit($seconditem->description, $limit = 100, $end = '...')); ?></div>
                                </div><!--end col-lg-9 col-xs-12-->
                            </div><!--end row-->
                            <div class="book_tools">
                                <a href="#"><i class="flaticon-paper fa-2x text-primary"></i></a>
                                <a book-id="<?php echo e($seconditem->id); ?>" class="read-book" href="/show-book/<?php echo e($seconditem->id); ?>"><i class="flaticon-fashion fa-2x text-primary"></i></a>
                                <a href="#" book-id="<?php echo e($seconditem->id); ?>" class="share-book"><i class="flaticon-connection fa-2x text-primary"></i></a>
                                <a href="#" book-id="<?php echo e($seconditem->id); ?>" class="download-book"><i class="flaticon-arrows fa-2x text-primary"></i></a>
                            </div><!--end book_tools-->
                        </div><!--end h_tab_book-->

                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endforeach; ?>

                    <?php endforeach; ?>




                </div>


            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>