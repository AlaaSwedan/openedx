<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>

	<label>إسم الموضوع الرئيسى</label>
	<input value="<?php echo e($maintopic->name); ?>" class="form-control" type="text" id='edit-maintopic-name-input' name="name"/><br/>
	<span id="editmtname-missing"></span>

	<label>الوصف</label><br/>
	<textarea name="edit_maintopic_description_input" id='edit_maintopic_description_input' rows="10" cols="30" class="form-control"><?php echo e($maintopic->description); ?></textarea><br/>
	<script>
            CKEDITOR.replace( 'edit_maintopic_description_input' );
    </script>_
	<span id="editmtdesc-missing"></span>

	<input main-id="<?php echo e($maintopic->id); ?>" type="submit" value="عدل موضوع رئيسى" id='edit-maintopic-add-input' class="form-control"/>

</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>