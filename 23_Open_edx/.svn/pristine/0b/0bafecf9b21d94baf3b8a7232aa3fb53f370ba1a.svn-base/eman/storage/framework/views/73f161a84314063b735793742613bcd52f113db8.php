<?php $__env->startSection('admin-content'); ?>

	<div class="row">
		<div class="col-xs-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">إدخال مستخدم</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" method="POST" action="<?php echo e(url('/admin-panel/users/addUser')); ?>">
            	<?php echo e(csrf_field()); ?>

              <div class="box-body">

              <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <div class="form-group">
                  <div class="col-sm-10" style="margin:10px;">
                    <input type="text" class="form-control" name="name" placeholder="اسم المستخدم">
                    <?php if($errors->has('name')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('name')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>

              <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <div class="form-group">
                  <div class="col-sm-10" style="margin:10px;">
                    <input type="text" class="form-control" name="email" placeholder="البريد الإلكتروني">
                    <?php if($errors->has('email')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                      </span>
                      <?php endif; ?>
                  </div>
                </div>
              </div>

              <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <div class="form-group">
                  <div class="col-sm-10" style="margin:10px;">
                    <input type="password" class="form-control" name="password" placeholder="كلمة السر">
                    <?php if($errors->has('password')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('password')); ?></strong>
                      </span>
                      <?php endif; ?>
                  </div>
                </div>
              </div>

            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
               <div class="form-group">
                <div class="col-sm-10" style="margin:10px;">
                  <input type="password" class="form-control" name="password_confirmation" placeholder="إعادة إدخال كلمة السر">
                    <?php if($errors->has('password_confirmation')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                      </span>
                      <?php endif; ?>
                </div>
                </div>
              </div>
            </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-info pull-right">إدخال</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
    </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>