<?php /* using ajax */ ?>
<div class="new_comment">
	<h4 class="text-success">أضف تعليقك</h4>
	<div class="form-group">
		<textarea id="book-comment" class="form-control" name="book-comment" rows="3" placeholder="اضف تعليقك هنا"></textarea>
	</div>
	<input type="submit"  id="add-comment" class="btn btn-success-outline" name="add-comment" value="إضافة" />
</div>
