<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head> 
    <meta charset="utf-8"/>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <?php /* ajax laravel */ ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <title>موسوعة التفسير الموضوعي</title>
    <meta name="description" content="موسوعة التفسير" />
    <meta property="og:title" content="تفسير" />
    <meta property="og:image" content="http://tafsir.azurewebsites.net/books/icons/17_20160831095141.png" />
    <meta property="og:description" content="موضوع" />
    <!--bootstrap links-->
    <?php
    $server = $_SERVER['SERVER_NAME'];
    $port = $_SERVER['SERVER_PORT'];
    foreach (glob("books/css/*.css") as $css) 
    {
        echo "<link type='text/css' rel='stylesheet' href='http://$server:$port/$css'>\n";
    }
    ?>
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/fonts.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/bootstrap-rtl.min.css')); ?>">
    <!--font-awesome links-->
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/flaticon.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/animate.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/wow_book.css')); ?>">

    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/new_grid.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/validationEngine.jquery.css')); ?>">
    
    <!--jQuery-->
    <script type="text/javascript" src="<?php echo e(url('js/jquery-1.12.4.min.js')); ?>"></script>
    <style>
        .highlight
        {
            background-color:yellow;
        }
        
    </style>
    <style>
        .anchor-toc:link{ color:#DEB887; text-decoration: none; }
        .anchor-toc:visited { color:#DEB887; text-decoration: none; }
        .anchor-toc:hover { color:#DEB887; text-decoration: none; }
        .anchor-toc:active { color:#DEB887; text-decoration: underline; }
        
    </style>
    
    <script>
        $(window).bind('load', function() {
            $("#book_loading").fadeOut("fast");
            $("#show_book_scroll_content").fadeIn("fast");
        });
    </script>

</head>
<body>
    <header>
        <div class="container">
            <a href="/" class="page_top_logo"><img src="<?php echo e(url('images/small-logo.png')); ?>" alt=""/></a>        
            <button class="btn text-muted page_menu_btn hidden-lg-up"><i class="fa fa-bars fa-lg"></i></button>
            <div class="clearfix hidden-lg-up"></div>
            <nav class="page_top_nav hidden-md-down">
                <ul class="ul_clear">
                    <li><a href="/">الرئيسية</a></li>
                    <li><a href="/about-us">عن الموسوعة</a></li>
                    <li><a href="/departments">إدارة الموسوعة</a></li>
                    
                    <?php if(Auth::guest()): ?>
                    <!-- Authentication Links -->
                    <li><a href="<?php echo e(url('/login')); ?>">دخول</a></li>
                    <li><a href="<?php echo e(url('/register')); ?>">انضم للموسوعة</a></li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <!-- Eman... user_profile -->
                            <li><a href='<?php echo e(url("/profile/".Auth::user()->id."")); ?>'><i class="fa fa-user"></i>صفحتى الشخصية</a></li>
                            <!-- end_user_profile -->
                            

                            <?php if(Auth::user()->is_admin): ?>
                            <li><a href="/admin-panel">لوحة التحكم</a></li>
                            <?php endif; ?>
                            
                            <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>خروج</a></li>

                        </ul>
                    </li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(url('/contact_us')); ?>">تواصل معنا</a></li>
                </ul>
            </nav><!--end top_head_nav-->
            <div class="clearfix"></div>
        </div><!--end container-->
    </header>
    <div class="menu_bar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <span class="menu_ico "><i class="flaticon-book fa-3x"></i></span><!--end menu_ico-->
                    <nav class="menu_nav">
                        <ul class="ul_clear">
                            <li><a href="<?php echo e(url('/')); ?>/show-folders">المجلدات</a></li>
                            <li><a href="<?php echo e(url('/')); ?>/show-letters">الأحرف</a></li>
                            <li><a href="<?php echo e(url('/')); ?>/show-topics">الموضوعات</a></li>
                        </ul>
                    </nav>
                    <div class="menu_search hidden-xs-down">
                        <form action='<?php echo e(url("/search")); ?>' role="form" method="get" class="from-group">
                            <button type="submit" class="btn"><i class="flaticon-tool fa-2x"></i></button>
                            <input type="text" name="search" class="form-control home-search" placeholder="ابحث في الموسوعة"/>
                        </form>
                    </div><!--end menu_search-->
                    <div class="clearfix"></div>
                </div><!--end col-xs-12-->
            </div><!--end row-->
        </div><!--end container-->
</div><!--end menu_bar-->