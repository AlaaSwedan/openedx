<?php $__env->startSection('admin-content'); ?>

<!-- Your Page Content Here -->
    <!-- Main content -->
      <div class="row" >
        <div class="col-md-9" style="width: 100%;">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">الصندوق الوارد لرسائل تواصل معنا</h3>
            
              <form action="<?php echo e(url('/admin-panel/messages/find')); ?>" method="get">
                <div class="input-group input-group-sm" style="width: 150px;margin-right:85%;">
                  <input type="text" name="search_input" class="form-control pull-right" placeholder="ابحث في الرسائل">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </form>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-controls">
                <!-- Check all button -->
                <button type="button" id="check_all" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
                </button>
                 <button type="button" class="btn btn-default btn-sm" id="delete_btn" disabled="1"><i class="fa fa-trash-o"></i></button>
                <button type="button" class="btn btn-default btn-sm" id="refresh"><i class="fa fa-refresh"></i></button>
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table">
                  <tbody>
			              <?php foreach($messages as $message): ?>
											<?php if($message->is_read): ?>
												<tr>
                    			<td><input type="checkbox" class="hibox" value="<?php echo e($message->id); ?>"></td>
													<td><a href="<?php echo e(url('/admin-panel/messages/'.$message->id.'/show')); ?>"><?php echo e($message->user_name); ?></a></td>
													<td><?php echo e($message->subject); ?></td>
													<td><?php echo e($message->created_at->format('Y-m-d')); ?></td>
												</tr>
											<?php else: ?>
												<tr bgcolor='#FFFAFA'>
                    			<td><input type="checkbox" class="hibox" value="<?php echo e($message->id); ?>"></td>
													<td><b><a href="<?php echo e(url('/admin-panel/messages/'.$message->id.'/show')); ?>"><?php echo e($message->user_name); ?></a></b></td>
													<td><b><?php echo e($message->subject); ?></b></td>
													<td><b><?php echo e($message->created_at->format('Y-m-d')); ?></b></td>
												</tr>
											<?php endif; ?>
										<?php endforeach; ?>
               
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer no-padding">
              <div class="mailbox-controls">
                <div class="pull-right">
                  <?php echo e($messages->currentPage()); ?> - <?php echo e($messages->perPage()); ?> / <?php echo e($messages_count); ?> &nbsp;&nbsp;&nbsp;
                </div>
                <!-- /.pull-right -->
                <?php echo $messages->render(); ?>

              </div>
              
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>