<?php $__env->startSection('admin-content'); ?>
<?php /* books */ ?>

<h1>Books</h1>
<table class="table">
  <caption>Books</caption>

  <form action="addBook.php" method="post">
    <button id="addBook" class="btn btn-default" style="margin:10px;">
      <span class="glyphicon glyphicon-plus"> Add Book</span>
    </button>  
  </form>
  <form action="addPage.php" method="post">
    <button id="add" class="btn btn-default" style="margin:10px;">
      <span class="glyphicon glyphicon-plus"> Add Page</span>
    </button>  
  </form>

  <form action="addTOC.php" method="post">
    <button id="add" class="btn btn-default" style="margin:10px;">
      <span class="glyphicon glyphicon-plus"> Add TOC</span>
    </button>  
  </form>

  <form action="showBooks.php" method="post">
    <button id="showBooks" class="btn btn-default" style="margin:10px;">
      <span class="glyphicon glyphicon-plus"> Show Books</span>
    </button>  
  </form>

  <button id="delete" class="btn btn-default" style="margin:10px;">
    <span class="glyphicon glyphicon-remove"> Delete</span>
  </button>
  <button id="refresh" class="btn btn-default" style="margin:10px;">
    <span class="glyphicon glyphicon-refresh"> Refresh</span>
  </button>
  <th>ID</th>
  <th>Title</th>
  <th>Upload PDF</th>
  <th>Upload Photo</th>
  <?php foreach($books as $book): ?>
  <tr>
    <td><a href="/show-book/<?php echo e($book->id); ?>"><?php echo e($book->id); ?></a></td>
    <td><a href="/show-book/<?php echo e($book->id); ?>"><?php echo e($book->title); ?></a></td>
    <td>
      <form action='<?php echo e(url("/upload-book/$book->id")); ?>' role="form" method="post" class="from-group" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <input type="file" class="form-control" name="book-pdf" value="upload pdf"/>
        <input type="submit" class="form-control" value="upload" />
      </form>
    </td>
    <td>
      <form action='<?php echo e(url("/upload-book-photo/$book->id")); ?>' role="form" method="post" class="from-group" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <input type="file" class="form-control" name="book-photo" value="upload photos"/>
        <input type="submit" class="form-control" value="upload" />
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>