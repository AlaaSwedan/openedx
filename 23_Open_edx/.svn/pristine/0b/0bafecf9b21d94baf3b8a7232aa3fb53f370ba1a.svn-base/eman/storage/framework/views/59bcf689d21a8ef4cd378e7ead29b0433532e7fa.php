<?php /* sarah */ ?>

<?php $__env->startSection('admin-content'); ?>
<section class="content">
	<div class="container">
		<div class="row">
			<div class="box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">أضف فهرس</h3>
					<h6>حدد نص واحد فقط</h6>
				</div>
			</div>
			<div class="col-md-6">

				<div class="form-group">
					<label class="form-control">عنوان فرعى</label>
					<input type="text" name="toc-title" id="toc-title" class="form-control"/>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="form-control">رقم الصفحة</label>
					<input type="text" name="page-num" id="toc-page-num" class="form-control"/>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">

				<label>الكتاب</label>
				<div style="overflow: scroll; height:200px;" name="book-pages-input" required id='book-pages-input-toc' class="form-control">
					<?php echo $pages; ?>

				</div>			
			</div>			

			<div class="form-group">
				<input type="hidden" id="book-toc-id" value="<?php echo e($book->id); ?>"/>
				<input type="button" class="btn btn-primary" id="save-toc" value="حفظ" />
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>