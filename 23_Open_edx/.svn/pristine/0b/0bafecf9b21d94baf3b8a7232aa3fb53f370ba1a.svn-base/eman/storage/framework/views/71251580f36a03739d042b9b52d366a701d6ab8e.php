<?php $__env->startSection('admin-content'); ?>
<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">الصفحات</h3>

        <div class="box-tools">
          <div class="input-group input-group-sm" style="width: 150px;">
            <input type="text" name="table_search" id="search" class="form-control pull-right" placeholder="إبحث">

            <div class="input-group-btn">
              <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
            </div>
          </div>
        </div>
      </div>


      <a id="addPage" href="/admin-panel/add-page-form" class="btn btn-default" style="margin:10px;">
       أضف صفحة <span class="fa fa-plus"></span>
     </a> 

     <a id="addPageJSON" href="/admin-panel/add-page-JSON-form" class="btn btn-default" style="margin:10px;">
       أضف صفحة من ملف <span class="fa fa-plus"></span>
     </a> 

     <a id="delete-page" class="btn btn-default disabled" style="margin:10px;">
       إحذف <span class="fa fa-trash-o"></span>
     </a>
     <a id="refresh" class="btn btn-default" style="margin:10px;">
       تنشيط <span class="fa fa-refresh"></span>
     </a>

     <select class="form-control" name="books" id="books-pages">
       <?php foreach($books as $book): ?>
       <option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>
       <?php endforeach; ?>
     </select>



     <!-- /.box-header -->
     <div class="box-body table-responsive no-padding">
      <table class="table table-hover sortable">
        <tr>
          <th><input type="checkbox" id="checkall"/> حدد الكل</th>
          <th><a href="#" id="s" class="btn btn-default"><i class="fa fa-fw fa-sort"></i> رقم الصفحة </a></th>
          <th><a href="#" class="btn btn-default"><i class="fa fa-fw fa-sort"></i> وقت النشر</a></th>
          <th>المحتوى</th>
          <th>عدل</th>
        </tr>
        <?php foreach($pages as $page): ?>
        <tr>
         <td><input type="checkbox" class="check" value="<?php echo e($page->id); ?>"/></td>
         <td><?php echo e($page->page_order); ?></td>
         <td><?php echo e($page->created_at); ?></td>

         <?php $sub = substr($page->content, 0, 50); ?>
         <td><?= $sub . " ..." ?></td>
         <td>
          <a href="/admin-panel/edit/page/<?php echo e($page->id); ?>" page-id="<?php echo e($page->id); ?>" class="btn btn-default edit-page" style="margin:10px;">
            <span class="fa fa-refresh"> عدل</span>
          </a>
        </td>
      </tr> 
      <?php endforeach; ?>
    </table>
    <?php echo e($pages->currentPage()); ?> / <?php echo e($pages->perPage()); ?>

      <?php echo $pages->render(); ?>


  </div>
  <!-- /.box-body -->
</div>
<!-- /.box -->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>