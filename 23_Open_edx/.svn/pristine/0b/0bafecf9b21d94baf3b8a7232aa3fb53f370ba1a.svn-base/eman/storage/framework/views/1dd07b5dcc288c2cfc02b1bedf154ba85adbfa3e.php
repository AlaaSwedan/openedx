<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="flaticon-fashion fa-lg"></i> الأكثر قراءة</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>
            <?php if($reads): ?>
            <?php foreach($reads as $read): ?>
            <?php foreach($books as $book): ?>

            <?php if($book->id == $read->book_id): ?>
            <?php if($book->is_published): ?>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12 home_most_read">
                <div class="book_box">
                    <a href="/show-book/<?php echo e($book->id); ?>">
                        <div class="box_img"><img src="<?php echo e(url('books/icons')); ?>/<?php echo e($book->image); ?>" alt=""/></div>
                        <div class="box_tools">
                            <ul class="ul_clear">
                                <li  data-toggle="tooltip" data-placement="top" title="طباعة">
                                    <a book-id="<?php echo e($book->id); ?>" target="_blank" href="/books/pdfs/<?php echo e($book->pdf); ?>" class="print_book"><i class="flaticon-paper fa-2x"></i></a>
                                </li>
                                <li data-toggle="tooltip" data-placement="top" title="قراءة الموضوع">
                                    <a book-id="<?php echo e($book->id); ?>" class="read-book" href="/show-book/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x"></i></a>
                                </li>
                                <li class="dropdown" data-toggle="tooltip" data-placement="top" title="مشاركة">
                                    <a name="share-button" data-toggle="dropdown" href="" book-id="<?php echo e($book->id); ?>"><i class="flaticon-connection fa-2x "></i></a>
                                    <div class="dropdown-menu social_share dropdown-menu-right">
                                        <ul class="ul_clear text-xs-center">
                                            <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="http://www.facebook.com/sharer.php?u=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&title=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-facebook"></i></a></li>
                                            <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://twitter.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&text=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-twitter"></i></a></li>
                                            <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://plus.google.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </li>
                                <li data-toggle="tooltip" data-placement="top" title="تحميل">
                                    <a href="/download/<?php echo e($book->id); ?>" book-id="<?php echo e($book->id); ?>" class="download-book"><i class="flaticon-arrows fa-2x"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div><!--end box_tools-->
                    </a>
                </div><!--end book_box-->
            </div><!--end col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12 home_most_read-->
            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; ?>
            <?php endforeach; ?>
            <?php else: ?>
            <div class="alert alert-danger no-margin">هذا المحتوى فارغ.</div>
            <?php endif; ?>
        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->
