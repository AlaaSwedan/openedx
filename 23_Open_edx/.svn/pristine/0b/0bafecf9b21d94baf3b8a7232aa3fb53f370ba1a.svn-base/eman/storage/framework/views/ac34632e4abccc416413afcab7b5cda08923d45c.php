<?php foreach($comments as $key => $value): ?>
<?php if($comments[$key]->text != ''): ?>
<div class="user_comment">
	<div class="com_user"></div>
	<h6><?php echo e($users[$key][0]->fullname); ?></h6>
	<?php /* created at */ ?>
	<span><?php echo e($comments[$key]->created_at); ?></span>

	<p><?php echo e($comments[$key]->text); ?></p>

</div>
<?php endif; ?>
<?php endforeach; ?>