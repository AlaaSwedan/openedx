<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>

	<label>إسم المدير</label>
	<input value="<?php echo e($manager->name); ?>" class="form-control" type="text" id='edit-manager-name-input' /><br/>
	<span id="editman-name-missing"></span>

	<label>المسمى الوظيفى</label>
	<input value="<?php echo e($manager->position); ?>" class="form-control" type="text" id='edit-manager-title-input' /><br/>
	<span id="editjob-name-missing"></span>

	<select class="form-control" id="edit-manager-dep-input">
		<?php foreach($deps as $dep): ?>
		<option value="<?php echo e($dep->id); ?>"><?php echo e($dep->title); ?></option>
		<?php endforeach; ?>
	</select><br/>

	<input manager-id="<?php echo e($manager->id); ?>" type="submit" value="عدل قسم" id='edit-manager-add-input' class="form-control"/>

</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>