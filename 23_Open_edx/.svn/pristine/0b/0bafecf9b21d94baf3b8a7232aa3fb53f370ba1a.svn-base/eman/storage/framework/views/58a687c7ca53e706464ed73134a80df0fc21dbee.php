<?php foreach($comments as $key => $value): ?>

<div class="user_comment">
	<div class="com_user"><img src="<?php echo e(url('images/p2.png')); ?>" alt=""/></div>
	<h6><?php echo e($users[$key][0]->name); ?></h6>
	<?php /* created at */ ?>
	<span><?php echo e($comments[$key]->created_at); ?></span>

	<p><?php echo e($comments[$key]->text); ?></p>

</div>
<?php endforeach; ?>