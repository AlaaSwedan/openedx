<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>
	<form action='<?php echo e(url("/admin-panel/edit/social")); ?>' role="form" method="post" class="from-group">
		<?php echo e(csrf_field()); ?>

		<?php foreach($socials as $social): ?>
		<label>فيسبوك</label>
		<input class="form-control" value="<?php echo e($social->facebook); ?>" type="text"  name="fb"/><br/>

		<label>تويتر</label>
		<input class="form-control" value="<?php echo e($social->twitter); ?>" type="text"  name="tw"/><br/>

		<label>مراسلات</label>
		<input class="form-control" value="<?php echo e($social->msg); ?>" type="text"  name="msg"/><br/>

		<label>إنستجرام</label>
		<input class="form-control" value="<?php echo e($social->instagram); ?>" type="text"  name="ins"/><br/>

		<label>يوتيوب</label>
		<input class="form-control" value="<?php echo e($social->youtube); ?>" type="text"  name="yt"/><br/>
		<?php endforeach; ?>

		<input type="submit" value="حفظ" class="form-control"/>
	</form>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>