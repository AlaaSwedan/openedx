<?php $__env->startSection('admin-content'); ?>
<?php /* abouts */ ?>
<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">عن الموقع</h3>

     <!-- /.box-header -->
     <div class="box-body table-responsive no-padding">
      <table class="table table-hover">
        <tr>
          <th>الرؤية</th>
          <th>الرسالة</th>
          <th>الأهداف</th>
          <th>المزايا</th>
          <th>الشرائح</th>
          <th>المخرجات</th>
        </tr>
        <?php /* <?php foreach($abouts as $about): ?> */ ?>
        <tr>
          <td><?php echo $about->visions; ?></td>
          <td><?php echo $about->messages; ?></td>
          <td><?php echo $about->goals; ?></td>
          <td><?php echo $about->advantages; ?></td>
          <td><?php echo $about->layers; ?></td>
          <td><?php echo $about->outputs; ?></td>
          <td>
            <a href="/admin-panel/edit/about/<?php echo e($about->id); ?>" about-id="<?php echo e($about->id); ?>" class="btn btn-default edit-about" >
               عدل <span class="fa fa-edit"></span>
            </a>
          </td>
       </tr>
       <?php /* <?php endforeach; ?> */ ?>
     </table>
   </div>
   <!-- /.box-body -->
 </div>
 <!-- /.box -->
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>