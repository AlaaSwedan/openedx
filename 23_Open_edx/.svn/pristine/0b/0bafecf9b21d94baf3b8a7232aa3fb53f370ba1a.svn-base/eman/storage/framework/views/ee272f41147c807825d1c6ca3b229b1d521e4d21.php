<?php $__env->startSection('admin-content'); ?>
<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">مواقع التواصل الإجتماعى</h3>

        <div class="box-tools">
          <div class="input-group input-group-sm" style="width: 150px;">
            <input type="text" id="search" name="table_search" class="form-control pull-right" placeholder="إبحث">

            <div class="input-group-btn">
              <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
            </div>
          </div>
        </div>
      </div>


      
     <a id="refresh" class="btn btn-default" style="margin:10px;">
       تنشيط <span class="fa fa-refresh"></span>
     </a>


     <!-- /.box-header -->
     <div class="box-body table-responsive no-padding">
      <table class="table table-hover">
        <tr>
          <th>فهرس المصادر و المراجع</th>
          <th>عدل</th>
        </tr>
        <tr>
         <td><?php echo $resource->resource; ?></td>
         <td>
         	<a href="/admin-panel/edit/resources" class="btn btn-default" >
               عدل <span class="fa fa-edit"></span>
            </a>
         </td>
       </tr> 
     </table>
     <?php /* <?php echo e($socials->currentPage()); ?> / <?php echo e($socials->perPage()); ?>

      <?php echo $socials->render(); ?> */ ?>
   </div>
   <!-- /.box-body -->
 </div>
 <!-- /.box -->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>