<?php $__env->startSection('content'); ?>
<?php /* single book 1 */ ?>
<section class="pages_content">
	<div class="container">
		<div class="row">
			<?php if($book != ''): ?>

			<div class="col-xs-12">
				<h1 class="page_title"> <i class="flaticon-book fa-lg"></i> كتاب / <?php echo e($book->title); ?></h1>
				<div class="card">
					<div class="card-header book_head">
						<span><img src='<?php echo e(url("photo/books/$book->image")); ?>'></span>
						<h6 class=" text-success line_text"><?php echo e($book->description); ?></h6>
						<div class="clearfix"></div>
					</div>
					<div class="rb_tools">
						<ul class="ul_clear book_read_tools pull-sm-left text-xs-center">
							<li><a href="#" id="book_menu_btn"><i class="fa fa-bars fa-2x" title="القائمة" data-toggle="tooltip" data-placement="top"></i></a></li>
							<li class="dropdown book_drop">
								<a href="#" data-toggle="dropdown">
									<i class="fa fa-bookmark-o fa-2x" title="المفضلة" data-toggle="tooltip" data-placement="top"></i>
								</a>
								<div class="dropdown-menu">
									<textarea book-id="<?php echo e($book->id); ?>" id="bookmark" name="bookmark" class="form-control" placeholder="أضف مفضلتك" rows="1"></textarea>
									<button id="add-bookmark" class="btn btn-success btn-sm center-block" type="button">إضافة</button>
								</div><!--end dropdown-menu-->
							</li><!--end dropdown book_drop-->
							<li class="dropdown book_drop">
								<a href="#" data-toggle="dropdown">
									<i class="fa fa-edit fa-2x" title="اضف ملاحظة" data-toggle="tooltip" data-placement="top"></i>
								</a>
								<div class="dropdown-menu">                                
									<textarea book-id="<?php echo e($book->id); ?>" id="note" class="form-control" placeholder="أضف ملاحظتك" rows="1"></textarea>
									<button id="add-note" class="btn btn-success btn-sm center-block" type="button">إضافة</button>
								</div><!--end dropdown-menu-->
							</li>
							<li class="dropdown book_drop" id="book_drop">
								<a href="#" data-toggle="dropdown">
									<i class="fa fa-list-alt fa-2x" title="الملاحظات المحفوظة" data-toggle="tooltip" data-placement="top"></i>
								</a>
								<div class="dropdown-menu" id="notes_tab">
									<ul  class="nav nav-tabs" role="tablist">
										<li class="nav-item" id="tabBookMarks">
											<a class="nav-link active" data-toggle="tab" href="#bookmark" role="tab">المفضلة</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-toggle="tab" href="#notes" role="tab">الملاحظات</a>
										</li>
									</ul>
									<div class="tab-content">
										<div class="tab-pane active" id="bookmark" role="tabpanel">
											<?php foreach($bookmarks as $bookmark): ?>
											<div class="notes_list">

												<a href="#" bookmark-id="<?php echo e($bookmark->id); ?>" class="delete-bookmark"><i class="fa fa-trash-o"></i></a>
												<a href="#" bookmark-id="<?php echo e($bookmark->id); ?>" class="edit-bookmark"><i class="fa fa-edit"></i></a>
												<h4><?php echo e($bookmark->text); ?></h4>
											</div><!--end notes_list-->
											<?php endforeach; ?>

											<!--end notes_list-->
										</div><!--end tab-pane-->

										<div class="tab-pane" id="notes" role="tabpanel">
											<?php foreach($notes as $note): ?>
											<div class="notes_list">
												<a href="#" note-id="<?php echo e($note->id); ?>" class="delete-note"><i class="fa fa-trash-o"></i></a>
												<a href="#"note-id="<?php echo e($note->id); ?>" class="edit-note"><i class="fa fa-edit"></i></a>
												<h4><?php echo e($note->text); ?></h4>
											</div><!--end notes_list-->
											<?php endforeach; ?>
										</div><!--end tab-pane-->
									</div><!--end tab-content-->
								</div><!--end dropdown-menu-->
							</li>
							<li><a href="/pdf/books/<?php echo e($book->id); ?>.pdf" target="_blank"><i class="flaticon-paper fa-2x" title="طباعة" data-toggle="tooltip" data-placement="top"></i></a></li>
							
							<li>
								<a href="/show-book/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x" title="" data-toggle="tooltip" data-placement="top" data-original-title="قراءة الموضوع بطريقه اخرى"></i></a>
								
							</li>

							<li><a href="#"><i class="flaticon-connection fa-2x" title="نشر" data-toggle="tooltip" data-placement="top"></i></a></li>
							<li><a href="/download/<?php echo e($book->id); ?>"><i class="flaticon-arrows fa-2x" title="تحميل" data-toggle="tooltip" data-placement="top"></i></a></li>

						</ul>
						<div class="book_read_page pull-sm-right text-xs-center">
							<a href="" id="bb-nav-next" class="book_nav" title="السابق" data-toggle="tooltip" data-placement="bottom"> <i class="fa fa-chevron-right fa-lg"></i></a>
							<span class=" h6 line_text">صفحة 1 من 18</span>
							<a href="" id="bb-nav-prev" class="book_nav" title="التالى" data-toggle="tooltip" data-placement="bottom"> <i class="fa fa-chevron-left fa-lg"></i></a>
						</div><!--end book-read-tools-->
						<div class="clearfix"></div>
					</div><!--end rb_tools-->

					<div class="bb-custom-wrapper b_menu_show" >
						<div class="sidebar_menu">
							<ul class="navigation" id="TOCList">
								<?php foreach($tocs as $toc): ?>
								<li class="b_scroll" ><a href="#scoll<?php echo e($toc->page_id); ?>" ><?php echo e($toc->title); ?></a></li>
								<?php endforeach; ?>
							</ul>		
						</div><!--end sidebar_menu-->
						<article id="bookText" class="book_article">
							<h4><?php echo e($book->description); ?></h4>
							<?php foreach($pages as $page): ?>
							<a id="scoll<?php echo e($page->id); ?>"></a>
							<p><?php echo e($page->content); ?></p>
							<?php endforeach; ?>
						</article>
						
					</div><!--bb-custom-wrapper-->


				</div><!--end card-->
				<hr/>

				<?php /* comments are here */ ?>
				<?php /* change this */ ?>
				<?php echo $__env->make('Comment.add-comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('Comment.list-comments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			</div><!--end col-xs-12-->
			<div class="clearfix"></div>
			<?php else: ?>
			<div class="alert alert-danger no-margin">هذا الكتاب غير موجود</div>
			<?php endif; ?>
		</div><!--end row-->
	</div><!--end container-->
</section><!--end pages_content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>