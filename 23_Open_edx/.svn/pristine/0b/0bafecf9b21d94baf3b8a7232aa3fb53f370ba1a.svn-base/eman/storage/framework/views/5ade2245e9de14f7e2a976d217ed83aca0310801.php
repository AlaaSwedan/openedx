 <?php 
 use App\Http\Controllers\SocialController;
 $socials = new SocialController;

 ?>
 <footer>
  <div class="container">
    <div class="row">
      <aside class="col-lg-6 col-md-8 col-xs-12">
        <nav class="footer_menu">
          <ul class="ul_clear">

            <li><a class="text-muted" href="/faq">مساعدة</a></li>
            <li><a class="text-muted" href="/support_us">دعم</a></li>
            <li><a class="text-muted" href="/contact-us">اتصل بنا</a></li>

          </ul>
        </nav>
        <address class="text-muted">المملكة العربية السعودية - الرياض - حي الغدير مخرج (5) طريق الملك عبد العزيز - خلف بنك ساب</address>
      </aside><!--end col-xs-12-->
      <aside class="col-lg-6 col-md-4 col-xs-12">

        <ul class="ul_clear footer_social">
          <li><a href="<?= $socials->pass()[0]; ?>" class="facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
          <li><a href="<?= $socials->pass()[1]; ?>" class="twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
          <li><a href="<?= $socials->pass()[2]; ?>" class="mail" target="_blank"><i class="fa fa-paper-plane-o"></i></a></li>
          <li><a href="<?= $socials->pass()[3]; ?>" class="instagram" target="_blank"><i class="fa fa-instagram"></i></a></li>
          <li><a href="<?= $socials->pass()[4]; ?>" class="youtube" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
        </ul>
      </aside><!--end col-xs-12-->
    </div><!--end row-->
  </div><!--end container-->
</footer>
<!--js files-->
<script type="text/javascript" src="<?php echo e(url('js/tether.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/bootstrap-select.min.js')); ?>"></script>   
<script type="text/javascript" src="<?php echo e(url('js/jquery.localScroll.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/jquery.scrollTo.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/icheck.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/iframeheight.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/jquery.validationEngine.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/jquery.validationEngine-ar.js')); ?>"></script>
<?php /* <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script> */ ?>

<script type="text/javascript">
$(document).ready(function(e) {
// sarah
    //ajax laravel
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });


//page id default
window.pageId=1;
// end sarah


$('[data-toggle="tooltip"]').tooltip()
$('.page_menu_btn').click(function(){
 $('.page_top_nav').toggleClass('hidden-md-down') ;
});
    //////////////////
    var res_header_height=$('body > header').height();  
    $(window).scroll(function(){
      var sticky = $('.menu_bar'),scroll = $(window).scrollTop();
      if (scroll >=res_header_height ) sticky.addClass('fixed_header');
      else sticky.removeClass('fixed_header');
    });
  });
</script>
<?php /* single book 1 */ ?>
<script type="text/javascript">
$(document).ready(function() {
  $('[data-toggle="tooltip"]').tooltip();
  $('.b_scroll').localScroll({
        target: '.book_article', // could be a selector or a jQuery object too.
        queue:true,
        duration:1000,
        hash:true,

      });
  $('.page_menu_btn').click(function(){
   $('.page_top_nav').toggleClass('hidden-md-down') ;
 });
  
  $( '#book_menu_btn' ).click(function(){
    $('.bb-custom-wrapper').toggleClass('b_menu_show') ;
    return false;
  });
  $('#notes_tab').on('click', '.nav-tabs a', function(){
    $(this).closest('.dropdown').addClass('dontClose');
  });

  $('#book_drop').on('hide.bs.dropdown', function(e) {
    if ( $(this).hasClass('dontClose') ){
      e.preventDefault();
    }
    $(this).removeClass('dontClose');
  });
    //////////////////
    var res_header_height=$('body > header').height();   
    $(window).scroll(function(){
      var sticky = $('.menu_bar'),scroll = $(window).scrollTop();
      if (scroll >=res_header_height ) sticky.addClass('fixed_header');
      else sticky.removeClass('fixed_header');
    });

    //page number
    // $("#pn").append($("#page-num").val());
    $("#bb-nav-prev").click(function (e) {
      e.preventDefault();
      $("#pn").empty();
      $("#pn").append($("#page-num").val()); 
    });
    
    $("#bb-nav-next").click(function (e) {
     e.preventDefault();
     $("#pn").empty();
     $("#pn").append($("#page-num").val());
   })
    
  });
 </script>
 <?php /* copy text */ ?>
 <script>
//     document.addEventListener('mouseup', function(){
//     var thetext = getSelectionText()
//     if (thetext.length > 0){ // check there's some text selected
//         alert(thetext) // logs whatever textual content the user has selected on the page
//     }
// }, false)
 </script>

 <?php /* sarah */ ?>
 <?php /* add bookmark */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/add-bookmark.js')); ?>"></script>
 <?php /* add Note */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/add-note.js')); ?>"></script>

 <?php /* add comment */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/add-comment.js')); ?>"></script>

 <?php /* delete note */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/delete-note.js')); ?>"></script>
 <?php /* delete bookmark */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/delete-bookmark.js')); ?>"></script>

 <?php /* edit note */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/edit-note.js')); ?>"></script>

 <?php /* edit bookmark */ ?>
 <script type="text/javascript" src="<?php echo e(url('js/edit-bookmark.js')); ?>"></script>

 <?php /* search */ ?>
 <script src="<?php echo e(url('js/front-search.js')); ?>"></script>

 <?php /* most download */ ?>
 <script src="<?php echo e(url('js/most-download.js')); ?>"></script>

 <?php /* most share */ ?>
 <script src="<?php echo e(url('js/most-share.js')); ?>"></script>

 <?php /* most read */ ?>
 <script src="<?php echo e(url('js/most-read.js')); ?>"></script>
 <?php /* search */ ?>
 <script src="<?php echo e(url('js/word-search.js')); ?>"></script>
 <?php /* end sarah */ ?>

 <?php /* Eman */ ?>
  <script src="<?php echo e(url('js/user_downloads.js')); ?>"></script>
  <script src="<?php echo e(url('js/user_prints.js')); ?>"></script>
  <script src="<?php echo e(url('js/user_shares.js')); ?>"></script>
  <script src="<?php echo e(url('js/highlight.js')); ?>"></script>

  <script src="<?php echo e(url('js/when_turning.js')); ?>"></script>
  <script src="<?php echo e(url('js/next_btn.js')); ?>"></script>
  <script src="<?php echo e(url('js/prev_btn.js')); ?>"></script>
  <script src="<?php echo e(url('js/show-book-toc.js')); ?>"></script>
  <script src="<?php echo e(url('js/show-hide-home.js')); ?>"></script>

</body>
</html>
