<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>
	<section class="pages_content">
    <div class="container">
			<div class="row">
		    <div class="col-xs-12">
		        <h1 class="page_title"> <i class="fa fa-envelope-o"></i> الدعم الفني</h1>
		    </div><!--end col-xs-12-->
		    <div class="clearfix"></div>
		    <div class="col-lg-6 col-md-6 col-xs-12">
		    <!-- contact form -->
		      <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/support_us/')); ?>">
		            <?php echo e(csrf_field()); ?>


		          <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">  
			          <div class="form-group">
			              <input type="text" class="form-control" name="name" placeholder="اسمك الكريم "/>
			              <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                    <?php endif; ?>
			          </div><!--end form-group-->
							</div>

							<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
			          <div class="form-group">
			              <input type="text" class="form-control" name="email" placeholder=" بريدك الإلكترونى "/>
                    <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
			          </div><!--end form-group-->
							</div>

							<div class="form-group<?php echo e($errors->has('subject') ? ' has-error' : ''); ?>">
			          <div class="form-group">
			              <input type="text" class="form-control" name="subject" placeholder=" الموضوع "/>
			              <?php if($errors->has('subject')): ?>
                		<span class="help-block">
                    	<strong><?php echo e($errors->first('subject')); ?></strong>
                		</span>
                <?php endif; ?>
			          </div><!--end form-group-->
							</div>

							<div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
			          <div class="form-group">
			              <textarea class="form-control" name="message" placeholder=" رسالتك" rows="6"></textarea>
			              <?php if($errors->has('message')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('message')); ?></strong>
                    </span>
                    <?php endif; ?>
			          </div><!--end form-group-->
							</div>

		          <div class="form-group">
		              <input type="submit" class="btn btn-secondary text-muted" name="submit" value="إرسال"/>
		          </div><!--end form-group-->
		      </form><!-- contact form -->
		    </div><!--end col-lg-6 col-md-6 col-xs-12-->
			</div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>