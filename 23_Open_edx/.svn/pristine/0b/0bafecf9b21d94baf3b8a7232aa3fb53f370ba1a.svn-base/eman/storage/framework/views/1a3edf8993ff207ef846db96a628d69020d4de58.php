<?php echo $__env->make('layouts.home_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="home_content" id="home_f">
    <?php /*  */ ?>
    <div class="container">
    <div id="change_content">
        <div class="home_books_tab">
            <div class="row">

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                    <h1 class="title">المجلدات</h1>
                    <ul class="ul_clear" role="tablist">
                        <?php for($i=0;$i<4;$i++): ?>
                        <?php if($folders[$i] != null): ?>
                        <?php if($folders[$i]->is_published): ?>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#tab<?php echo e($folders[$i]->id); ?>" role="tab"><?php echo e($folders[$i]->name); ?> <i class="fa fa-angle-left"></i></a>
                        </li>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php endfor; ?>
                    </ul>
                </div><!--end col-xs-12-->
                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                 <div class="tab-content">
                    <?php if($folders[0] != null): ?>
                    <?php if($folders[0]->is_published): ?>
                     <div class="tab-pane fade in active" id="tab<?php echo e($folders[0]->id); ?>" role="tabpanel">
                        <?php foreach($folders[0]->books()->get() as $book): ?>
                        <?php if($book->is_published): ?>
                        <?php if(!$book->is_suspended): ?>
                        <div class="h_tab_book">
                          <a href="/show-book/<?php echo e($book->id); ?>">

                            <div class="row">
                                <div class="col-lg-3 col-md-4 col-xs-12">
                                    <div class="book_img"><img src="<?php echo e(url('books/icons')); ?>/<?php echo e($book->image); ?>" alt=""></div>
                                </div><!--end col-lg-3 col-xs-12-->
                                <div class="col-lg-9 col-md-8 col-xs-12">
                                    <div class="book_content text-muted line_text"><p><?php echo $book->description; ?></p></div>
                                </div><!--end col-lg-9 col-xs-12-->
                            </div><!--end row-->    
                            <div class="book_tools">
                                <ul class="ul_clear">
                                    <li  data-toggle="tooltip" data-placement="top" title="طباعة">
                                        <a book-id="<?php echo e($book->id); ?>" target="_blank" href="/books/pdfs/<?php echo e($book->pdf); ?>" class="print_book"><i class="flaticon-paper fa-2x text-primary"></i></a>
                                    </li>

                                    <li data-toggle="tooltip" data-placement="top" title="قراءة الموضوع">
                                        <a book-id="<?php echo e($book->id); ?>" class="read-book" href="/show-book/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x text-primary"></i></a>
                                    </li>
                                    <li class="dropdown" data-toggle="tooltip" data-placement="top" title="مشاركة">
                                        <a name="share-button" data-toggle="dropdown" href="" book-id="<?php echo e($book->id); ?>"><i class="flaticon-connection fa-2x text-primary"></i></a>
                                        <div class="dropdown-menu social_share dropdown-menu-right">
                                            <ul class="ul_clear text-xs-center">
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="http://www.facebook.com/sharer.php?u=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&title=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-facebook"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://twitter.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&text=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-twitter"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://plus.google.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li data-toggle="tooltip" data-placement="top" title="تحميل">
                                        <a href="/download/<?php echo e($book->id); ?>" book-id="<?php echo e($book->id); ?>" class="download-book"><i class="flaticon-arrows fa-2x text-primary"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div><!--end book_tools-->
                        </a>
                        
                    </div><!--end h_tab_book-->
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </div><!--end tab-pane-->
                <?php endif; ?>
                <?php endif; ?>
                <?php if($folders[1] != null): ?>
                <?php if($folders[1]->is_published): ?>
                <div class="tab-pane fade" id="tab<?php echo e($folders[1]->id); ?>" role="tabpanel">
                    <?php foreach($folders[1]->books()->get() as $book): ?>
                    <div class="h_tab_book">
                        <div class="row">
                            <div class="col-lg-3 col-md-4 col-xs-12">
                                <div class="book_img"><img src="<?php echo e(url('books/icons')); ?>/<?php echo e($book->image); ?>" alt=""></div>
                            </div><!--end col-lg-3 col-xs-12-->
                            <div class="col-lg-9 col-md-8 col-xs-12">
                                <div class="book_content text-muted line_text"><p><?php echo $book->description; ?></p></div>
                            </div><!--end col-lg-9 col-xs-12-->
                        </div><!--end row-->                                    
                        <div class="book_tools">
                                <ul class="ul_clear">
                                    <li  data-toggle="tooltip" data-placement="top" title="طباعة">
                                        <a book-id="<?php echo e($book->id); ?>" target="_blank" href="/books/pdfs/<?php echo e($book->pdf); ?>" class="print_book"><i class="flaticon-paper fa-2x text-primary"></i></a>
                                    </li>

                                    <li data-toggle="tooltip" data-placement="top" title="قراءة الموضوع">
                                        <a book-id="<?php echo e($book->id); ?>" class="read-book" href="/show-book/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x text-primary"></i></a>
                                    </li>
                                    <li class="dropdown" data-toggle="tooltip" data-placement="top" title="مشاركة">
                                        <a name="share-button" data-toggle="dropdown" href="" book-id="<?php echo e($book->id); ?>"><i class="flaticon-connection fa-2x text-primary"></i></a>
                                        <div class="dropdown-menu social_share dropdown-menu-right">
                                            <ul class="ul_clear text-xs-center">
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="http://www.facebook.com/sharer.php?u=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&title=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-facebook"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://twitter.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&text=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-twitter"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://plus.google.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li data-toggle="tooltip" data-placement="top" title="تحميل">
                                        <a href="/download/<?php echo e($book->id); ?>" book-id="<?php echo e($book->id); ?>" class="download-book"><i class="flaticon-arrows fa-2x text-primary"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div><!--end book_tools-->
                    </div><!--end h_tab_book-->
                    <?php endforeach; ?>
                </div><!--end tab-pane-->
                <?php endif; ?>
                <?php endif; ?>
                <?php if($folders[2] != null): ?>
                <?php if($folders[2]->is_published): ?>
                <div class="tab-pane fade" id="tab<?php echo e($folders[2]->id); ?>" role="tabpanel">
                    <?php foreach($folders[2]->books()->get() as $book): ?>
                    <div class="h_tab_book">
                        <div class="row">
                            <div class="col-lg-3 col-md-4 col-xs-12">
                                <div class="book_img"><img src="<?php echo e(url('books/icons')); ?>/<?php echo e($book->image); ?>" alt=""></div>
                            </div><!--end col-lg-3 col-xs-12-->
                            <div class="col-lg-9 col-md-8 col-xs-12">
                                <div class="book_content text-muted line_text"><p><?php echo $book->description; ?></p></div>
                            </div><!--end col-lg-9 col-xs-12-->
                        </div><!--end row-->                                    
                        <div class="book_tools">
                                <ul class="ul_clear">
                                    <li  data-toggle="tooltip" data-placement="top" title="طباعة">
                                        <a book-id="<?php echo e($book->id); ?>" target="_blank" href="/books/pdfs/<?php echo e($book->pdf); ?>" class="print_book"><i class="flaticon-paper fa-2x text-primary"></i></a>
                                    </li>

                                    <li data-toggle="tooltip" data-placement="top" title="قراءة الموضوع">
                                        <a book-id="<?php echo e($book->id); ?>" class="read-book" href="/show-book/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x text-primary"></i></a>
                                    </li>
                                    <li class="dropdown" data-toggle="tooltip" data-placement="top" title="مشاركة">
                                        <a name="share-button" data-toggle="dropdown" href="" book-id="<?php echo e($book->id); ?>"><i class="flaticon-connection fa-2x text-primary"></i></a>
                                        <div class="dropdown-menu social_share dropdown-menu-right">
                                            <ul class="ul_clear text-xs-center">
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="http://www.facebook.com/sharer.php?u=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&title=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-facebook"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://twitter.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&text=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-twitter"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://plus.google.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li data-toggle="tooltip" data-placement="top" title="تحميل">
                                        <a href="/download/<?php echo e($book->id); ?>" book-id="<?php echo e($book->id); ?>" class="download-book"><i class="flaticon-arrows fa-2x text-primary"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div><!--end book_tools-->
                    </div><!--end h_tab_book-->
                    <?php endforeach; ?>
                </div><!--end tab-pane-->
                <?php endif; ?>
                <?php endif; ?>
                <?php if($folders[3] != null): ?>
                <?php if($folders[3]->is_published): ?>
                <div class="tab-pane fade" id="tab<?php echo e($folders[3]->id); ?>" role="tabpanel">
                    <?php foreach($folders[3]->books()->get() as $book): ?>
                    <div class="h_tab_book">
                        <div class="row">
                            <div class="col-lg-3 col-md-4 col-xs-12">
                                <div class="book_img"><img src="<?php echo e(url('books/icons')); ?>/<?php echo e($book->image); ?>" alt=""></div>
                            </div><!--end col-lg-3 col-xs-12-->
                            <div class="col-lg-9 col-md-8 col-xs-12">
                                <div class="book_content text-muted line_text"><p><?php echo $book->description; ?></p></div>
                            </div><!--end col-lg-9 col-xs-12-->
                        </div><!--end row-->                                    
                        <div class="book_tools">
                                <ul class="ul_clear">
                                    <li  data-toggle="tooltip" data-placement="top" title="طباعة">
                                        <a book-id="<?php echo e($book->id); ?>" target="_blank" href="/books/pdfs/<?php echo e($book->pdf); ?>" class="print_book"><i class="flaticon-paper fa-2x text-primary"></i></a>
                                    </li>

                                    <li data-toggle="tooltip" data-placement="top" title="قراءة الموضوع">
                                        <a book-id="<?php echo e($book->id); ?>" class="read-book" href="/show-book/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x text-primary"></i></a>
                                    </li>
                                    <li class="dropdown" data-toggle="tooltip" data-placement="top" title="مشاركة">
                                        <a name="share-button" data-toggle="dropdown" href="" book-id="<?php echo e($book->id); ?>"><i class="flaticon-connection fa-2x text-primary"></i></a>
                                        <div class="dropdown-menu social_share dropdown-menu-right">
                                            <ul class="ul_clear text-xs-center">
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="http://www.facebook.com/sharer.php?u=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&title=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-facebook"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://twitter.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>&text=<?php echo e($book->title); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-twitter"></i></a></li>
                                                <li><a book-id="<?php echo e($book->id); ?>" class="share-book" rel="nofollow" href="https://plus.google.com/share?url=http://tafser.herokuapp.com/show-book/<?php echo e($book->id); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li data-toggle="tooltip" data-placement="top" title="تحميل">
                                        <a href="/download/<?php echo e($book->id); ?>" book-id="<?php echo e($book->id); ?>" class="download-book"><i class="flaticon-arrows fa-2x text-primary"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div><!--end book_tools-->
                    </div><!--end h_tab_book-->
                    <?php endforeach; ?>
                </div><!--end tab-pane-->
                <?php endif; ?>
                <?php endif; ?>

            </div>
        </div><!--end col-xs-12-->
    </div><!--end row-->

</div><!--end home_books_tab-->
</div>
</div>
</section>

<?php echo $__env->make('layouts.home_read', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.home_download', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.home_share', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.home_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>