<?php if($comments != ''): ?>
	<?php foreach($comments as $key => $value): ?>
		<?php if($comments[$key]->text != ''): ?>
			<div id="append_new_comment">
				<div class="user_comment" >
					<h6><?php echo e($users[$key][0]->fullname); ?></h6>
					<span><?php echo e($comments[$key]->created_at->format('Y-m-d')); ?></span>
					<p><?php echo e($comments[$key]->text); ?></p>
				</div>
			</div>
		<?php endif; ?>
	<?php endforeach; ?>
<?php else: ?>
	<div id="append_new_comment">
	</div>
<?php endif; ?>