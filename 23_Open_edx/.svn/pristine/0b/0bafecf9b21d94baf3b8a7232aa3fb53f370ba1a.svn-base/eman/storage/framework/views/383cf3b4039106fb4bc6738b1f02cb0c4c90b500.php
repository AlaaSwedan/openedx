<?php $__env->startSection('content'); ?>
<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="fa fa-exclamation"></i>  عن الموسوعة</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>
            <div class="col-xs-12">
                <a class="about_title"><i class="fa fa-eye fa-lg"></i> رؤية المشروع</a>
                <h4 class="about_content"> <?php echo $about->visions; ?></h4>
                
                <a class="about_title" ><i class="fa fa-envelope fa-lg"></i> رسالة  المشروع</a>
                <h4 class="about_content"> <?php echo $about->messages; ?></h4>
                
                <a class="about_title"><i class="fa fa-crosshairs fa-lg"></i> أهداف   المشروع</a>
                <h4 class="about_content"> <?php echo $about->goals; ?></h4>
                 
                <a class="about_title"><i class="fa fa-thumb-tack fa-lg"></i>مميزات الموسوعة</a>
                <h4 class="about_content"> <?php echo $about->advantages; ?></h4>
                  
                <a class="about_title"><i class="fa fa-clone fa-lg"></i>الشرائح المستهدفة</a>
                <h4 class="about_content"> <?php echo $about->layers; ?></h4>
                  
                <a class="about_title"><i class="fa fa-random fa-lg"></i>مخرجات المشروع</a>
                <h4 class="about_content"> <?php echo $about->outputs; ?></h4>
                 
            </div><!--end  col-xs-12-->
        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>