<?php $__env->startSection('admin-content'); ?>
<?php /* books */ ?>

<h1>الصفحات</h1>
<table class="table">
  <caption>الصفحات</caption>

  <a id="addPage" href="/admin-panel/add-page-form" class="btn btn-default" style="margin:10px;">
    <span class="glyphicon glyphicon-plus"> أضف صفحة</span>
  </a>  

  
  <a id="delete-page" class="btn btn-default" style="margin:10px;">
    <span class="glyphicon glyphicon-remove"> إحذف</span>
  </a>
  <a id="refresh" class="btn btn-default" style="margin:10px;">
    <span class="glyphicon glyphicon-refresh"> تنشيط</span>
  </a>

    <select class="form-control" name="books" id="books-pages">
     <?php foreach($books as $book): ?>
     <option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>
     <?php endforeach; ?>
   </select>

 <th><a href="#" class="btn btn-default"><i class="fa fa-fw fa-sort"></i> رقم</a></th>
 <th><a href="#" class="btn btn-default"><i class="fa fa-fw fa-sort"></i> وقت النشر</a></th>
 <th>المحتوى</th>
 <th><input type="checkbox" id="checkall"/> حدد الكل</th>
 <?php foreach($pages as $page): ?>
 <tr>
   <td><?php echo e($page->id); ?></td>
   <td><?php echo e($page->created_at); ?></td>
  
   <?php $sub = substr($page->content, 0, 50); ?>
   <td><?= $sub . " ..." ?></td>

   <td><input type="checkbox" class="check" value="<?php echo e($page->id); ?>"/></td>
 </tr> 
 <?php endforeach; ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>