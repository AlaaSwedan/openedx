<?php /* sarah */ ?>

<?php $__env->startSection('admin-content'); ?>
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">عدل فهرس</h3>
				</div>	
				<form role="form" action"<?php echo e(url('/admin-panel/add-toc')); ?>" method="post">
					<?php echo e(csrf_field()); ?>


					<div class="box-body">
						<label>الصفحة الفرعية</label>
						<input class="form-control" type="text" name="toc"/>
						<br/>

						<label>رقم الصفحة</label>
						<input class="form-control" type="text" name="page_order"/>
						<br/>

						<label>إسم الكتاب:</label>
						<select class="form-control book" name="book">	
							<?php foreach($books as $book): ?>
							<option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>

							<?php endforeach; ?>
						</select>
						<br/>

						<div class="box-footer">
							<button type="submit" class="btn btn-primary">إحفظ</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>