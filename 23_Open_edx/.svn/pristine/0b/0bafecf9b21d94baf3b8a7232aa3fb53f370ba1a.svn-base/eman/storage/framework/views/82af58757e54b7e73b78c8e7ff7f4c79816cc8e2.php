<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"><i class="flaticon-arrows fa-lg"></i> الأكثر تحميلاً</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>


            <?php foreach($downloads as $item1): ?>
            <?php foreach($books as $item2): ?>

            <?php if($item2->id == $item1->book_id): ?>

            <div class="col-lg-3 col-md-4 col-sm-6  col-xs-12 home_most_down">
                <div class="book_box">
                    <div class="box_tools">
                        <a href="#"><i class="flaticon-paper fa-lg" title="طباعة" data-toggle="tooltip" data-placement="top"></i></a>
                        <a href="#"><i class="flaticon-connection fa-lg" title="نشر" data-toggle="tooltip" data-placement="top"></i></a>
                        <a href="#"><i class="flaticon-arrows fa-lg" title="تحميل" data-toggle="tooltip" data-placement="top"></i></a>
                    </div>
                    <div class="box_img"><img src="<?php echo e(url('/')); ?>/<?php echo e($item2->image); ?>" alt=""/></div>
                </div><!--end book_box-->
            </div><!--end col-lg-3 col-xs-12-->

            <?php endif; ?>
             <?php endforeach; ?>
            <?php endforeach; ?>

        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->