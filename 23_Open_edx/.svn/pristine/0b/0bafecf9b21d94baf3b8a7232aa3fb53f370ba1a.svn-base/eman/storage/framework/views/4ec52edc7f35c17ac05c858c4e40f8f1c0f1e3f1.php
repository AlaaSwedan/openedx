<?php $__env->startSection('content'); ?>



<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="fa fa-th "></i>الأحرف</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>


            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <ul class="ul_clear letters_tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active"  href="<?php echo e(url('/')); ?>/show-letters/أ">
                        أ
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>/show-letters/ب" role="tab">ب</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>/show-letters/ت" role="tab">ت</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>/show-letters/ث" role="tab">ث</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>/show-letters/ج" role="tab">ج</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>/show-letters/ح" role="tab">ح</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>/show-letters/خ"  role="tab">خ</a>
                    </li>
                </ul>
            </div><!--end col-xs-12-->



            <div class="col-xl-10 col-lg-9 col-md-8 col-sm-8 col-xs-12">
                <div class="tab-content">
                    <div class="tab-pane fade in active" id="tab1" role="tabpanel">


            <?php foreach($books as $item): ?>
            <?php if(! empty($ch)): ?>
            <?php if($item->first_letter == $ch): ?>


                        <div class="let_tab_book">
                            <div class="row">
                                <div class="col-lg-3  col-xs-12">
                                    <div class="book_img text-xs-center"><img src="<?php echo e(url('/')); ?>/<?php echo e($item->image); ?>" alt=""/></div>
                                </div><!--end col-lg-3 col-xs-12-->
                                <div class="col-lg-9  col-xs-12">
                                    <div class="book_content text-muted line_text"> <?php echo e(str_limit($item->description, $limit = 300, $end = '...')); ?> </div>
                                </div><!--end col-lg-9 col-xs-12-->
                            </div><!--end row-->
                            <div class="book_tools">
                                <a href="#"><i class="flaticon-paper fa-2x" title="طباعة" data-toggle="tooltip" data-placement="top"></i></a>
                                <a href="<?php echo e(url('/')); ?>/show-shares"><i class="flaticon-connection fa-2x" title="نشر" data-toggle="tooltip" data-placement="top"></i></a>
                                <a href="<?php echo e(url('/')); ?>/show-downloads"><i class="flaticon-arrows fa-2x" title="تحميل" data-toggle="tooltip" data-placement="top"></i></a>
                            </div><!--end book_tools-->
                        </div><!--end h_tab_book-->
            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; ?>







                    </div><!--end tab-pane-->

                </div><!--end tab-content-->
            </div><!--end col-xs-12-->



        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>