<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head> 
    <meta charset="utf-8"/>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <?php /* ajax laravel */ ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <title>موسوعة التفسير الموضوعي</title>
    <!--bootstrap links-->
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/bootstrap-rtl.min.css')); ?>">
    <!--font-awesome links-->
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/flaticon.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/animate.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/flipbook.css')); ?>">

    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/new_grid.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/validationEngine.jquery.css')); ?>">
    <!--jQuery-->
    <script type="text/javascript" src="<?php echo e(url('js/jquery-1.12.4.min.js')); ?>"></script>
    <style>
    .highlight
    {
        background-color:yellow;
    }
    </style>

</head>
<body>
    <header>
        <div class="container">
            <a href="/" class="page_top_logo"><img src="<?php echo e(url('images/small-logo.png')); ?>" alt=""/></a>  
        </div><!--end container-->
    </header>
    	<div style="margin:100px;color:red;">
			<h3>عفوًا هناك خطأ في الموقع الآن <br/>نحاول إصلاح هذا الخطأ.</h3>
		</div>
	 <footer>
	  <div class="container">
	    <div class="row">
		    <aside class="col-lg-6 col-md-8 col-xs-12">
			    <address class="text-muted">المملكة العربية السعودية - الرياض - حي الغدير مخرج (5) طريق الملك عبد العزيز - خلف بنك ساب</address>
	      	</aside><!--end col-xs-12-->
	    	
    	</div><!--end row-->
  	</div><!--end container-->
</footer>
</body>
</html>
