<?php $__env->startSection('admin-content'); ?>
<div class="row">
	<div class="col-xs-12">
		<div class="box">
			<div class="box-header">
				<h3 class="box-title">الملفات</h3>

				<div class="box-tools">
					<div class="input-group input-group-sm" style="width: 150px;">
						<input type="text" id="search" name="table_search" class="form-control pull-right" placeholder="إبحث">

						<div class="input-group-btn">
							<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>

			<a id="addFolder" href="/admin-panel/add-folder" class="btn btn-default" style="margin:10px;">
				أضف ملف <span class="fa fa-plus"></span>
			</a>  

			<a id="delete-folder" class="btn btn-default disabled" style="margin:10px;">
				إحذف <span class="fa fa-trash-o"></span>
			</a>
			<a id="refresh" class="btn btn-default" style="margin:10px;">
				تنشيط <span class="fa fa-refresh"></span>
			</a>



			<!-- /.box-header -->
			<div class="box-body table-responsive no-padding">
				<table class="table table-hover">
					<tr>
						<th><input type="checkbox" id="checkall"/> حدد الكل</th>
						<th>إسم المجلد</th>
						<th>الوصف</th>
						<th>الحالة</th>
						<th>عدل</th>
					</tr>
					<?php foreach($folders as $folder): ?>
					<tr>
						<td><input type="checkbox" class="check" value="<?php echo e($folder->id); ?>"/></td>
						<td><?php echo e($folder->name); ?></td>
						<td><?php echo e($folder->description); ?></td>
						<td>
							<?php if($folder->is_published): ?>
							<a folder-id="<?php echo e($folder->id); ?>" class="btn btn-danger unpublish-folder" style="margin:10px;">
								لا تنشر <span class="fa fa-refresh"></span>
							</a>
							<?php else: ?>
							<a folder-id="<?php echo e($folder->id); ?>" class="btn btn-primary publish-folder" style="margin:10px;">
								انشر <span class="fa fa-refresh"></span>
							</a>
							<?php endif; ?>
						</td>
						<td>
							<a href="/admin-panel/edit/folder/<?php echo e($folder->id); ?>" folder-id="<?php echo e($folder->id); ?>" class="btn btn-default edit-folder" style="margin:10px;">
								 عدل <span class="fa fa-refresh"></span>
							</a>
						</td>
					</tr>
					<?php endforeach; ?>
				</table>
				<?php echo e($folders->currentPage()); ?> / <?php echo e($folders->perPage()); ?>

				<?php echo $folders->render(); ?>

			</div>
			<!-- /.box-body -->
		</div>
		<!-- /.box -->
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>