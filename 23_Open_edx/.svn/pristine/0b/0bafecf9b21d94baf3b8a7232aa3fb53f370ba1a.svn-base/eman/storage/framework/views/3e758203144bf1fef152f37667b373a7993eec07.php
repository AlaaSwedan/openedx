<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>

	<label>إسم المجلد</label>
	<input class="form-control" type="text" id='folder-name-input' name="name"/><br/>
	<span id="foldername-missing"></span>
	<label>الوصف</label><br/>
	<textarea name="folder_description_input" id='folder_description_input' rows="10" cols="30" class="form-control"></textarea><br/>
	<script>
            CKEDITOR.replace( 'folder_description_input' );
    </script>
	<span id="folderdesc-missing"></span>
	<input type="submit" value="أضف مجلد" id='folder-add-input' class="form-control"/>

</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>