<?php $__env->startSection('content'); ?>
<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="fa fa-sign-in fa-flip-horizontal"></i> تسجيل الدخول </h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>
            <div class="col-xl-6 col-xl-offset-3 col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12">
                <div class="form-group">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" data-toggle="tooltip" data-placement="top" title="البريد الالكتروني" placeholder="البريد الالكتروني"/>
                            <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div><!--end form-group-->

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input id="password" type="password" class="form-control" name="password" data-toggle="tooltip" data-placement="top" title="كلمة المرور " placeholder="كلمة المرور"/>
                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div><!--end form-group-->
                        <input type="submit" class="btn btn-secondary" value="دخول"/>
                        <a href="<?php echo e(url('/password/reset')); ?>" class="pull-xs-right btn text-muted">نسيت كلمة المرور؟</a>


                    </form>
                </div><!--end  col-xs-12-->
                <div class="col-xs-12"></div>
            </div><!--end row-->
        </div><!--end container-->
    </section><!--end pages_content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>