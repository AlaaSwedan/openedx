<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php /* ajax laravel */ ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <title>موسوعة التفسير الموضوعي</title>
    <!--bootstrap links-->
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/bootstrap-rtl.min.css')); ?>">
    <!--font-awesome links-->
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/flaticon.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/animate.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('css/responsive.css')); ?>">
    <!--jQuery-->
    <script type="text/javascript" src="<?php echo e(url('js/jquery-2.2.0.min.js')); ?>"></script>
<?php /* loading */ ?>
    <style>
        /* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url(<?php echo e(URL::asset('images/loading.gif')); ?>) center no-repeat #fff;
}
</style>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<?php /* <script>
    //paste this code under head tag or in a seperate js file.
    // Wait for window load
    $(window).load(function() {
        // Animate loader off screen
        $(".se-pre-con").fadeOut("slow");;
    });
</script> */ ?>
</head>
<body>
    <header class="home_header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <button class="btn text-muted top_menu_btn hidden-md-up"><i class="fa fa-bars fa-lg"></i></button>
                    <nav class="top_head_nav hidden-sm-down">
                        <ul class="ul_clear">
                            <li><a href="/">الرئيسية</a></li>
                            <li><a href="/about-us">عن الموسوعة</a></li>
                            <li><a href="/departments">إدارة الموسوعة</a></li>
                            
                            <?php if(Auth::guest()): ?>
                                <li><a href="/login">دخول</a></li>
                                <li><a href="/register">انضم للموسوعة</a></li>
                            <?php else: ?>
                                <li class="dropdown">
                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false">
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
                                    <ul class="dropdown-menu" role="menu">
                                        <!-- Eman... user_profile -->
                                        <li><a href='<?php echo e(url("/profile/".Auth::user()->id."")); ?>'><i class="fa fa-user"></i> صفحتى الشخصية </a></li>
                                        <!-- end_user_profile -->

                                        <?php if(Auth::user()->is_admin): ?>
                                            <li><a href="/admin-panel">لوحة التحكم</a></li>
                                        <?php endif; ?>
                                        <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i> خروج </a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <li><a href="/contact_us">تواصل معنا</a></li>
                        </ul>
                    </nav><!--end top_head_nav-->
                    <div class="clearfix"></div>
                    <a href="/" class="top_logo"><img src="<?php echo e(url('/')); ?>/images/logo.png" alt=""/></a>
                    <h1 class="text-muted text-xs-center h3 site_desc">أول موسوعة علمية محكمة لدراسة موضوعات القرآن الكريم</h1>
                    <div class="main_head_cat">
                        <ul class="ul_clear">
                            <li><a href="#" class="book_scroll" id="folders_scroll"><span><img src="<?php echo e(url('/')); ?>/images/book.png" alt=""/></span> المجلدات</a></li>
                            <li><a href="#" class="book_scroll" id="letters_scroll"><span><img src="<?php echo e(url('/')); ?>/images/words.png" alt=""/></span>الأحرف</a></li>
                            <li><a href="#" class="book_scroll" id="topics_scroll"><span><img src="<?php echo e(url('/')); ?>/images/subjects.png" alt=""/></span>الموضوعات</a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div><!--end main_head_cat-->
                </div><!--end col-xs-12-->
            </div><!--end row-->
            <div class="row top_search_row">
                <div class="col-xl-8 col-lg-7 col-xs-12">
                    <div class="top_search">
                        <form action='<?php echo e(url("/search")); ?>' role="form" method="get" class="from-group">

                            <button type="submit" class="btn text-muted"><i class="flaticon-tool fa-2x"></i></button>
                            <input name="search" type="text" class="form-control home-search" placeholder="ابحث في الموسوعة"/>
                        </form>
                        <span class="clearfix"></span>
                    </div><!--end top_search-->
                </div><!--end col-lg-8-->
                <div class="col-xl-4 col-lg-5 col-xs-12 text-xs-center">
                    <a href="#" class="top_app">تطبيق Andriod على <br/>Google Play <span><i class="fa fa-android fa-2x"></i></span></a>
                    <a href="#" class="top_app">تطبيق IOS على  <br/>Itunes <span><i class="fa fa-apple fa-2x"></i></span></a>
                </div><!--end col-lg-4-->
            </div><!--end row-->
            <div class="row">
                <div class="col-xs-12 text-xs-center"><button class="btn scroll_to"><i class="fa fa-chevron-down"></i></button></div>
            </div><!--end row-->
        </div><!--end container-->
    </header>
    <div class="menu_bar home_bar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <span class="menu_ico "><i class="flaticon-book fa-3x"></i></span><!--end menu_ico-->
                    <nav class="menu_nav">
                        <ul class="ul_clear">
                            <li><a href="show-folders">المجلدات</a></li>
                            <li><a href="show-letters">الأحرف</a></li>
                            <li><a href="show-topics">الموضوعات</a></li>
                        </ul>
                    </nav>
                    <div class="menu_search hidden-xs-down">
                        <form action='<?php echo e(url("/search")); ?>' role="form" method="get" class="from-group">
                            <button type="submit" class="btn"><i class="flaticon-tool fa-2x"></i></button>
                            <input name="search" type="text" class="form-control home-search" placeholder="ابحث في الموسوعة"/>
                        </form>
                    </div><!--end menu_search-->
                    <div class="clearfix"></div>
                </div><!--end col-xs-12-->
            </div><!--end row-->
        </div><!--end container-->
</div><!--end menu_bar-->