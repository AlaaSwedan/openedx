<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
	<div class="alert alert-success" style="width:300px;margin-top:30px;margin-right:30px">
	    <p style="margin-right:30px">لقد تم إرسال رسالتك بنجاح.</p>
	</div>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

