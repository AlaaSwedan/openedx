<?php $__env->startSection('admin-content'); ?>
<div class="form-group">
	<?php /* ajax */ ?>

	<label>السؤال</label>
	<input class="form-control" type="text" id='faq-name-input' name="name"/><br/>
	<span id="q-missing"></span>
	<label>الإجابة</label><br/>
	<textarea name="desc" id='faq-answer-input' rows="10" cols="30" class="form-control"></textarea><br/>
	<span id="a-missing"></span>
	
	<input type="submit" value="أضف سؤال" id='faq-add-input' class="form-control"/>

</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>