<?php $__env->startSection('content'); ?>
<?php /* single book 1 */ ?>
<section class="pages_content">
	<div class="container">
		<div class="row">
			<?php if($book != ''): ?>
			<?php if($book->is_published): ?>
			<div class="col-xs-12">
				<h1 class="page_title"> <i class="flaticon-book fa-lg"></i><?php echo e($book->title); ?></h1>
				<div class="card">
					<div class="card-header book_head">
						<span><img src='<?php echo e(url("books/icons/$book->image")); ?>'></span>
						<?php /* <h6 class=" text-success line_text"><?php echo e($book->description); ?></h6> */ ?>
						<div class="clearfix"></div>
					</div>
					<div class="rb_tools">
						<ul class="ul_clear book_read_tools pull-sm-left text-xs-center">
							<li><a href="#" id="book_menu_btn"><i class="fa fa-bars fa-2x" title="القائمة" data-toggle="tooltip" data-placement="top"></i></a></li>
							<li class="dropdown book_drop">
								<a href="#" data-toggle="dropdown">
									<i class="fa fa-bookmark-o fa-2x" title="أضف مفضلة" data-toggle="tooltip" data-placement="top"></i>
								</a>
								<div class="dropdown-menu">
									<textarea book-id="<?php echo e($book->id); ?>" id="bookmark" name="bookmark" class="form-control" placeholder="أضف مفضلتك" rows="1"></textarea>
									<button id="add-bookmark" class="btn btn-success btn-sm center-block" type="button">إضافة</button>
								</div><!--end dropdown-menu-->
							</li><!--end dropdown book_drop-->
							<li class="dropdown book_drop">
								<a href="#" data-toggle="dropdown">
									<i class="fa fa-edit fa-2x" title="اضف ملاحظة" data-toggle="tooltip" data-placement="top"></i>
								</a>
								<div class="dropdown-menu">                                
									<textarea book-id="<?php echo e($book->id); ?>" id="note" class="form-control" placeholder="أضف ملاحظتك" rows="1"></textarea>
									<button id="add-note" class="btn btn-success btn-sm center-block" type="button">إضافة</button>
								</div><!--end dropdown-menu-->
							</li>
							<li class="dropdown book_drop" id="book_drop">
								<a href="#" data-toggle="dropdown">
									<i class="fa fa-list-alt fa-2x" title="الملاحظات المحفوظة" data-toggle="tooltip" data-placement="top"></i>
								</a>
								<div class="dropdown-menu" id="notes_tab">
									<ul  class="nav nav-tabs" role="tablist">
										<li class="nav-item" id="tabBookMarks">
											<a class="nav-link active" data-toggle="tab" href="#bookmark_tabs" role="tab">المفضلة</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-toggle="tab" href="#notes_tabs" role="tab">الملاحظات</a>
										</li>
									</ul>
									<div class="tab-content">
										<div class="tab-pane active" id="bookmark_tabs" role="tabpanel">
											<?php foreach($bookmarks as $bookmark): ?>
											<div class="notes_list">

												<a href="#" bookmark-id="<?php echo e($bookmark->id); ?>" class="delete-bookmark"><i class="fa fa-trash-o"></i></a>
												<a href="#" bookmark-id="<?php echo e($bookmark->id); ?>" class="edit-bookmark"><i class="fa fa-edit"></i></a>
												<h4><?php echo e($bookmark->text); ?></h4>
											</div><!--end notes_list-->
											<?php endforeach; ?>

											<!--end notes_list-->
										</div><!--end tab-pane-->

										<div class="tab-pane" id="notes_tabs" role="tabpanel">
											<?php foreach($notes as $note): ?>
											<div class="notes_list">
												<a href="#" note-id="<?php echo e($note->id); ?>" class="delete-note"><i class="fa fa-trash-o"></i></a>
												<a href="#" note-id="<?php echo e($note->id); ?>" class="edit-note"><i class="fa fa-edit"></i></a>
												<h4><?php echo e($note->text); ?></h4>
											</div><!--end notes_list-->
											<?php endforeach; ?>
										</div><!--end tab-pane-->
									</div><!--end tab-content-->
								</div><!--end dropdown-menu-->
							</li>
							<li><a book-id="<?php echo e($book->id); ?>" class="print_book" href="/books/pdfs/<?php echo e($book->pdf); ?>" target="_blank"><i class="flaticon-paper fa-2x" title="طباعة" data-toggle="tooltip" data-placement="top"></i></a></li>

							<li>
								<a book-id="<?php echo e($book->id); ?>" class="read-book" href="/show-book-scroll/<?php echo e($book->id); ?>"><i class="flaticon-fashion fa-2x" title="" data-toggle="tooltip" data-placement="top" data-original-title="قراءة الموضوع بالطريقة النصية"></i></a>
							</li>
							<li  class="dropdown book_drop">
								<a name="share-button" href="" data-toggle="dropdown"> <i class="flaticon-connection fa-2x" title="مشاركة" data-toggle="tooltip" data-placement="top"></i></a>
								<div class="dropdown-menu">
									<!-- AddToAny BEGIN -->
									<div class="a2a_kit a2a_kit_size_32 a2a_default_style" style="width:210px;">
										<a book-id="<?php echo e($book->id); ?>" class="share-book a2a_dd" href="https://www.addtoany.com/share"></a>
										<a book-id="<?php echo e($book->id); ?>" class="share-book a2a_button_facebook"></a>
										<a book-id="<?php echo e($book->id); ?>" class="share-book a2a_button_twitter"></a>
										<a book-id="<?php echo e($book->id); ?>" class="share-book a2a_button_google_plus"></a>
									</div>
									<script async src="https://static.addtoany.com/menu/page.js"></script>
									<!-- AddToAny END -->
								</div>
							</li>
							<li><a book-id="<?php echo e($book->id); ?>" class="download-book" href="/download/<?php echo e($book->id); ?>"><i class="flaticon-arrows fa-2x" title="تحميل" data-toggle="tooltip" data-placement="top"></i></a></li>
						</ul>
						<div class="book_read_page pull-sm-right text-xs-center">
							<a href="" id="prev_btn" class="book_nav" title="السابق" data-toggle="tooltip" data-placement="bottom"> <i class="fa fa-chevron-right fa-lg"></i></a>
							<span class=" h6 line_text">صفحة <span id="pn">1</span> من <?php echo e($dir_elements_count); ?></span>&nbsp;&nbsp;&nbsp;
							<a href="" id="next_btn" class="book_nav" title="التالى" data-toggle="tooltip" data-placement="bottom"> <i class="fa fa-chevron-left fa-lg"></i></a>
						</div><!--end book-read-tools-->
						<div class="clearfix"></div>
					</div><!--end rb_tools-->
					
					<div class="bb-custom-wrapper">
						<div class="sidebar_menu">
							<ul id="TOCList">
								<?php /* TOC */ ?>
								<?php /* <li><a href="">رابط الصفحة 1</a></li> */ ?>
								<?php foreach($tocs as $toc): ?>
								<li><a href="#" order="<?php echo e($toc->page_order); ?>" class="show-book-toc"><?php echo e($toc->title); ?></a></li>
								<input type="hidden" value="<?php echo e($toc->page_order); ?>" id="pageOrder_<?php echo e($toc->page_order); ?>" name="TOCPage"/>
								<?php endforeach; ?>
							</ul>
						</div><!--end sidebar_menu-->
						<!--//////////////////////////////////////////////////////////////////////////////////////-->

						<div class="flipbook-viewport">
							<div class="cont">
								<div id="flipbook" class="flipbook">
									<?php for($i = 0; $i < $dir_elements_count; $i++): ?>
									<div style="background-image:url(<?php echo e(url($dir_name.'/'.$files_name[$i+2])); ?>)"></div>
									<?php endfor; ?>
								</div><!--end flipbook-->
							</div><!--end cont-->
						</div><!--end flipbook-viewport-->
						<!--//////////////////////////////////////////////////////////////////////////////////////-->
					</div><!--bb-custom-wrapper-->
				</div><!--end card-->

				<hr/>
				<h1 class="page_title"> <i class="flaticon-book fa-lg"></i>   موضوعات ذات صلة  </h1>
				<div class="row">
					<?php if($books_in_topic != ''): ?>
					<?php foreach($books_in_topic as $book_topic): ?>
					<?php if($book_topic->id != $book->id): ?>
					<?php if($book_topic->is_published): ?>
					<div class="col-md-4 col-xs-12">
						<div class="book_block">
							<a href="/show-book/<?php echo e($book_topic->id); ?>">
								<div class="row">
									<div class="col-lg-4 col-md-12 col-sm-6 col-xs-12 text-xs-center">
										<div class="block_img">
											<img src="<?php echo e(url('/books/icons')); ?>/<?php echo e($book_topic->image); ?>" alt=""/>
										</div>
									</div><!--end col-xs-12-->
									<div class="col-lg-8 col-md-12 col-sm-6 col-xs-12">
										<div class="block_content text-muted">
											<font color="#0EAE90"><?php echo str_limit($book_topic->title, $limit = 30, $end = ' ... '); ?></font>
											<p><?php echo str_limit($book_topic->description, $limit = 30, $end = ' ... '); ?></p>
										</div>
									</div><!--end col-xs-12-->
								</div><!--end row-->
							</a>
						</div><!--end book_box-->
					</div><!--end col-xs-12-->
					<?php endif; ?>
					<?php endif; ?>
					<?php endforeach; ?>
					<?php else: ?>
					<div class="col-lg-8 col-md-12 col-sm-6 col-xs-12">
						<p class="alert alert-danger">لا توجد موضوعات تحت هذا الموضوع.</p>
					</div>
					<?php endif; ?>
				</div><!--end row-->
				<hr/>
				<?php /* comments are here */ ?>
				<?php /* change this */ ?>
				<?php echo $__env->make('Comment.add-comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('Comment.list-comments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			</div><!--end col-xs-12-->
			<div class="clearfix"></div>
			<?php else: ?>
			<div class="alert alert-danger no-margin">هذا الكتاب غير منشور بعد</div>
			<?php endif; ?>
			<?php else: ?>
			<div class="alert alert-danger no-margin">هذا الكتاب غير موجود</div>
			<?php endif; ?>
		</div><!--end row-->
	</div><!--end container-->
</section><!--end pages_content -->
<script type="text/javascript" src="<?php echo e(url('js/modernizr.2.5.3.min.js')); ?>"></script>
<script type="text/javascript">

function loadApp() {

  // Create the flipbook

  $('.flipbook').turn({
    width:922,
    height:600,
    direction: "rtl",
    elevation: 50,
    gradients: true,
    autoCenter: true,
    next:true

  });
}

// Load the HTML4 version if there's not CSS transform

yepnope({
  test : Modernizr.csstransforms,
  yep: ['<?php echo e(url('js/turn.min.js')); ?>'],
  // nope: ['../../lib/turn.html4.min.js'],
  // both: ['css/basic.css'],
  complete: loadApp
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>