<?php $__env->startSection('content'); ?>
<section class="pages_content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="page_title"> <i class="fa fa-pencil"></i> انضم للموسوعة</h1>
            </div><!--end col-xs-12-->
            <div class="clearfix"></div>
            <div class="col-xl-6 col-xl-offset-3 col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12">
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group<?php echo e($errors->has('fullname') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <input  id="fullname" type="text" name="fullname" value="<?php echo e(old('fullname')); ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="الاسم كاملاً" placeholder="الاسم كاملاً"/>
                            <?php if($errors->has('fullname')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('fullname')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div><!--end form-group-->
                    </div>


                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <input  id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="اسم المستخدم" placeholder="اسم المستخدم"/>
                            <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div><!--end form-group-->
                    </div>


                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <div class="form-group">

                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" data-toggle="tooltip" data-placement="top" title="البريد الإلكتروني" placeholder="البريد الإلكتروني">

                            <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <div class="form-group">

                            <input id="password" type="password" class="form-control" name="password" data-toggle="tooltip" data-placement="top" title="كلمة السر" placeholder="كلمة السر">

                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" data-toggle="tooltip" data-placement="top" title="أعد إدخال كلمة السر" placeholder="أعد إدخال كلمة السر"/>

                            <?php if($errors->has('password_confirmation')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <input type="submit" class="btn btn-secondary" value="تسجيل"/>
                </form>

            </div><!--end  col-xs-12-->
            <div class="col-xs-12"></div>
        </div><!--end row-->
    </div><!--end container-->
</section><!--end pages_content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>