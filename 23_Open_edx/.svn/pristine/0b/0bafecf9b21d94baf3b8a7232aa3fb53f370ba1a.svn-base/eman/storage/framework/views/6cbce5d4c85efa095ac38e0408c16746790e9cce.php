<?php /* sarah */ ?>

<?php $__env->startSection('admin-content'); ?>
<div class="row">
	<div class="col-xs-12">
		<div class="box">
			<div class="box-header">
				<h3 class="box-title">الفهارس</h3>

				<div class="box-tools">
					<div class="input-group input-group-sm" style="width: 150px;">
						<input type="text" id="search" name="table_search" class="form-control pull-right" placeholder="إبحث">

						<div class="input-group-btn">
							<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>

			<a id="addTocJSON" href="/admin-panel/add-toc-JSON-form" class="btn btn-default" style="margin:10px;">
				أضف فهرس من ملف <span class="fa fa-plus"></span>
			</a> 

			<a id="delete-toc" class="btn btn-default disabled" style="margin:10px;">
				إحذف <span class="fa fa-trash-o"></span>
			</a>
			<a id="refresh" class="btn btn-default" style="margin:10px;">
				تنشيط <span class="fa fa-refresh"></span>
			</a>



			<!-- /.box-header -->
			<div class="box-body table-responsive no-padding">
				<table class="table table-hover">
					<tr>
						<th><input type="checkbox" id="checkall"/> حدد الكل</th>
						<th>عنوان الكتاب</th>
						<th>أضف فهرس</th>
					</tr>
					<?php foreach($books as $book): ?>
					<tr>
						<td><input type="checkbox" class="check" value="<?php echo e($book->id); ?>"/></td>
						<td><?php echo e($book->title); ?></td>
						<td>
							<a href="/admin-panel/add-toc/<?php echo e($book->id); ?>" book-id="<?php echo e($book->id); ?>"" class="btn btn-default" >
								 أضف فهرس <span class="fa fa-plus"></span>
							</a>
						</td>
						
					</tr>
					<?php endforeach; ?>
				</table>
				<?php echo e($books->currentPage()); ?> / <?php echo e($books->perPage()); ?>

				<?php echo $books->render(); ?>

			</div>
			<!-- /.box-body -->
		</div>
		<!-- /.box -->
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>