<?php $__env->startSection('admin-content'); ?>
	
	<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">المستخدمون</h3><br/><br/>

              <div class="box-tools"><br/>
                <form action="<?php echo e(url('/admin-panel/users/find')); ?>" method="get">
                  <div class="input-group input-group-sm" style="width: 160px;">
                    <input type="text" name="serach_input" class="form-control pull-right" placeholder="ابحث عن مستخدم">

                    <div class="input-group-btn">
                      <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
	            <div class="mailbox-controls">
	                <!-- Check all button -->
	                <button type="button" id="check_all" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
	                </button>
	                 <button type="button" class="btn btn-default btn-sm" id="delete_btn2" disabled="1"><i class="fa fa-trash-o"></i></button>
                  <button type="button" class="btn btn-default btn-sm" id="refresh"><i class="fa fa-refresh"></i></button>
	            </div>
              <div class="col-md-6 col-xs-12 col-md-offset-4 col-xs-offset-2">
                <a href="<?php echo e(url('/admin-panel/users/addUser')); ?>" class="btn btn-primary btn-sm" style="width:120px">إضافة مستخدم</a>
                <a href="<?php echo e(url('/admin-panel/users/addUsers')); ?>" class="btn btn-primary btn-sm" style="width:120px">إضافة مستخدمين</a>
              </div><br/><br/>
	            <div>
              <table class="table table-hover">
              	<tr>
                  <th>تحديد</th>
                  <th>اسم المستخدم</th>
                  <th>البريد الإلكتروني</th>
                  <th>تاريخ الالتحاق</th>
                  <th>الحالة</th>
                  <th>تعديل بيانات المستخدم</th>
                  <th>إعادة إرسال لينك التفعيل</th>
                </tr>
              	<?php foreach($users as $user): ?>
                <?php if($user->name == ""): ?>
                <?php else: ?>
              		<tr>
										<td align="center"><input type="checkbox" class="hibox" value="<?php echo e($user->id); ?>"></td>
										<td align="center"><?php echo e($user->name); ?></td>
										<td><?php echo e($user->email); ?></td>
										<td align="center"><?php echo e($user->created_at->format('Y-m-d')); ?></td>
										<td align="center">
											<?php if($user->is_active): ?>
												<span class="label label-success"> موافق عليه </span>
											<?php else: ?>
												<span class="label label-warning"> في الانتظار </span>
											<?php endif; ?>
										</td>
                    <td align="center">
                      <a href="<?php echo e(url('/admin-panel/users/'.$user->id.'/edit')); ?>"><span class="label label-info" style="height:20pxك"> تعديل </span></a>
                    </td>
                    <td align="center">
                      <a href="<?php echo e(url('/admin-panel/users/'.$user->id.'/verify/resend')); ?>"><span class="label label-success" style="height:20pxك"> إرسال </span></a>
                    </td>
									</tr>
                  <?php endif; ?>
              	<?php endforeach; ?>
              </table>    
            </div>
            <!-- /.box-body -->
            <?php echo e($users->currentPage()); ?> - <?php echo e($users->perPage()); ?> / <?php echo e($users_count); ?> &nbsp;&nbsp;&nbsp;
          </div>
          <?php echo $users->render(); ?>

          <!-- /.box -->
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>