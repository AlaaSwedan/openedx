<?php

return array(

    'appNameIOS'     => array(
        'environment' =>'development',
        'certificate' =>'/path/to/certificate.pem',
        'passPhrase'  =>'password',
        'service'     =>'apns'
    ),
    'appNameAndroid' => array(
        'environment' =>'production',
        'apiKey'      =>'AAAA68bY7hg:APA91bGcfn1YeVXCGGPdf0YSGdcqmGM8QR4nOh2thu9xkPCzc27V3EnS9-dLsugXEgQGCwY5vf8eWuYY7fkXzlval-tegEBE1BE1UmZQp81sSgpFlN5bx6aga36Z12Vk2S6rFEfIQDCtsVp6i65Zf0ygGfq-EbaVcQ',
        'service'     =>'gcm'
    )

);