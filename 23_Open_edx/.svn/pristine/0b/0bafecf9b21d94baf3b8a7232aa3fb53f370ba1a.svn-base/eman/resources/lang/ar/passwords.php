<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'كلمة السر يجب أن تحتوي على الأقل على 8 حروف ويجب أن تعيد إدخالها.',
    'reset' => 'لقد تم إعادة تعيين كلمة المرور.',
    'sent' => 'لقد قمنا بإرسال رابط إعادة تعيين كلمة المرور لك.',
    'token' => 'This password reset token is invalid.',
    'user' => "عذرا هذا البريد الإلكتروني غير موجود.",

];
