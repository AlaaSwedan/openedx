<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>دلتا سوفت</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="index2.html"><b>دلتا</b>سوفت</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body" style="direction: rtl;">
    <p class="login-box-msg">الدخول للحساب</p>

      <div class="form-group has-feedback">
        <input id="username" type="text" class="form-control" placeholder="اسم المستخدم">
        <span class="fa fa-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input id="password" type="password" class="form-control" placeholder="كلمة المرور">
        <span class="fa fa-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-4">
          <button id="loginID" type="button" class="btn btn-primary btn-block btn-flat">دخول</button>
        </div>
        <!-- /.col -->
        <div class="col-xs-8">
        </div>
        <!-- /.col -->
      </div>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
  $("#loginID").click(function(){
    if($("#username").val()!='' && $("#password").val()!=''){
        $.get("/ws/login?username="+$("#username").val()+"&password="+$("#password").val(),function(data){
            // console.log(data);
            if(data.code == '200'){
                localStorage.setItem("userid", data.userid);
                localStorage.setItem("username", data.username);
                window.location.href="/home";
            }else{
                alert("ادخل بيانات الدخول بطريقة صحيحة");
            }
        });
    }else{
        alert("يجب ادخال اسم المستخدم وكلمة المرور");
    }
  });
</script>
</body>
</html>
