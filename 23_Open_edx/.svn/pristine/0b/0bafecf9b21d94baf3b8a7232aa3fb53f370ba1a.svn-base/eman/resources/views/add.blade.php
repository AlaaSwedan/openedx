<div class="row">
	<div class="col-md-12">
		<!-- general form elements -->
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title">إضافة إعلان</h3>
			</div>
			<!-- /.box-header -->
			<!-- form start -->
			<form role="form" class="form-horizontal" id="add_form">
				<div class="box-body">
					<div class="form-group">
						<label for="advertisementName" class="col-sm-2 control-label" >اسم الاعلان</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="advertisementName" placeholder="اسم الاعلان">
						</div>
					</div>
					<div class="form-group">
						<label for="type" class="col-sm-2 control-label" >النوع</label>
						<div class="col-sm-10">
							<select id="type" class="form-control">
								<option value="رسالة نصية" id="" showHide="msg">رسالة نصية</option>
								<option value="رسالة نصية + رابط" id="" showHide="msgUrl">رسالة نصية + رابط</option>
								<option value="رابط" id="" showHide="url">رابط</option>
								<option value="صورة" id="" showHide="image">صورة</option>
								<option value="صورة + رسالة" id="" showHide="imageMsg">صورة + رسالة</option>
							</select>
						</div>
					</div>
					<!--<div class="form-group option-feilds msg msgUrl imageMsg" >
						<label for="" class="col-sm-2 control-label" >نص الرسالة</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="msgText" placeholder="نص الرسالة">
						</div>
					</div>
					<div class="form-group  option-feilds url msgUrl">
						<label for="" class="col-sm-2 control-label" > الرابط</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="urlText" placeholder=" الرابط">
						</div>
					</div>
					<div class="form-group  option-feilds url msgUrl">
						<label for="" class="col-sm-2 control-label" > رفع الملف</label>
						<div class="col-sm-10">
							<input type="file" class="form-control" id="InputFile">
						</div>
					</div>-->
					<div class="form-group">
						<label for="" class="col-sm-2 control-label" >التصنيف</label>
						<div class="col-sm-10">
							<select id="category" class="form-control" onchange="doAction();">
								<option value="سيارات" id="">سيارات</option>
								<option value="اجهزة منزلية" id="">اجهزة منزلية</option>
								<option value="الكترونيات" id="">الكترونيات</option>
								<option value="اجهزة كمبيوتر" id="">اجهزة كمبيوتر</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="amount" class="col-sm-2 control-label">الرصيد</label>
						<div class="col-sm-10">
							<input type="number" class="form-control" id="amount" placeholder="الرصيد">
						</div>
					</div>
					<div class="form-group">
						<label for="status" class="col-sm-2 control-label">الحالة</label>
						<div class="col-sm-10">
							<select id="status" class="form-control">
								<option value="نشط" id="">نشط</option>
								<option value="غير نشط" id="">غير نشط</option>
							</select>
						</div>
					</div>

					<div class="form-group">
						<label for="segment" class="col-sm-2 control-label">الفئة المستهدفة</label>
						<div class="col-sm-10">
							<select id="segment" class="form-control">
								<option value="student" id="">طالب</option>
								<option value="teacher" id="">مدرس</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="place" class="col-sm-2 control-label">المكان</label>
						<div class="col-sm-10">
							<select id="place" class="form-control">
								<option value="الكل" id="">الكل</option>
								<option value="الرياض" id="">الرياض</option>
								<option value="جدة" id="">جدة</option>
								<option value="المدينة" id="">المدينة</option>
								<option value="الدمام" id="">الدمام</option>
								<option value="مكة" id="">مكة</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="owner" class="col-sm-2 control-label">صاحب الاعلان</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="owner" placeholder="صاحب الاعلان">
						</div>
					</div>
				</div>
				<!-- /.box-body -->

				<div class="box-footer">
					<button id="saveBT" type="button" class="btn btn-primary" onclick="add_advertisements();" >
						حفظ
					</button>
					<button id="editBT" type="button" class="edit_bt btn btn-primary" url="/add">
						تعديل
					</button>
					<button id="newBT" onclick="goToURL(this);" type="button" class=" edit_bt btn btn-primary getUrl" url="/add" title="إضافة اعلان">
						إضافة اعلان جديد
					</button>
				</div>
			</form>
		</div>
		<!-- /.box -->
	</div>
	<input type="hidden" value="" id="editID">
</div>
<script>
	$(document).ready(function() {
		$(".edit_bt").hide();
		$("#editBT").click(function(){
			$("#add_form .form-control").each(function(){
				$(this).attr('disabled',false);
			});
			$("#editBT").hide();
			$("#saveBT").show();
			$("#newBT").show();
		});
		if ($("#hiddenID").val() != '' && $("#hiddenID").val() != "undefined") {
			getDataByID();
		}
	});
	function doAction(){
		$(".option-feilds").hide();
		$("."+$("#type").find('option:selected').attr("showHide")+"").show();
	}
	function getDataByID() {
		$.get("/ws/getDataByID?id=" + $("#hiddenID").val(), function(data) {
			if (data.length > 0) {
				$("#newBT").show();
				$("#advertisementName").val(data[0]['advertiseName']);
				$("#type").val(data[0]['type']);
				$("#category").val(data[0]['category']);
				$("#amount").val(data[0]['amount']);
				$("#status").val(data[0]['status']);
				$("#segment").val(data[0]['segment']);
				$("#place").val(data[0]['place']);
				$("#owner").val(data[0]['owner']);
			}
		});
	}

	function add_advertisements() {

		advertisementName = $("#advertisementName").val();
		id = '';
		type = $("#type").val();
		category = $("#category").val();
		amount = $("#amount").val();
		status = $("#status").val();
		segment = $("#segment").val();
		place = $("#place").val();
		owner = $("#owner").val();

		if ($("#hiddenID").val() != '' && $("#hiddenID").val() != "undefined") {
			id = $("#hiddenID").val();
		 }
		$.get("ws/add_advertisements?advertisementName="+advertisementName+"&type="+type+"&category="+category+"&amount="+amount+"&status="+status+"&segment="+segment+"&place="+place+"&owner="+owner+"&id="+id , 
			function(data) {
			if (data) {
				advertise_id = data.advertise_id;
				$("#editID").val(advertise_id);
				$("#add_form .form-control").each(function(){
					$(this).attr('disabled',true);
				});
				$(".edit_bt").show();
				$("#saveBT").hide();
				alert("تم الحفظ بنجاح");
			}
		});
	}
</script>